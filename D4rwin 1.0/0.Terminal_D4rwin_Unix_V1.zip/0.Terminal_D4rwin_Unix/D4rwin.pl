#!/usr/bin/perl
use strict;
use File::Spec;
my $total_steps;
my $spp;
open my $log, '>>', "./log.txt" or die "Cannot open log.txt: $!";
print $log "Welcome to D4rwin V.1";
sub print_in_square {
    my ($text) = @_;
    my $text_length = length($text);
    
    
    my $border_char = '+';
    my $horizontal_char = '-';
    my $vertical_char = '|';
    
    
    my $border = $border_char . ($horizontal_char x ($text_length + 2)) . $border_char;
    
    
    my $middle_line = "$vertical_char $text $vertical_char";
    
    
    print "\t$border\n";
    print "\t$middle_line\n";
    print "\t$border\n";
}


sub prompt {
    my ($message) = @_;
    chomp(my $input = <STDIN>);  
    return $input;
}


print_in_square("Welcome to D4rwin V.1!");
print "\tPlease provide one of the following commands for:\n";
print_in_square("Assembling Taxonomic Database");
print "\ttxnmc_db_only\n";
print_in_square("BLAST stage");
print "\tblst_only\n";
print_in_square("Clustering Sequences");
print "\tclstr_only\n";
print_in_square("Formatting Sequences to the format >species_accession_number");
print "\treformat\n";
print_in_square("Assembling Taxonomic Database Available in NCBI, BLAST and Clustering Sequences");
print "\ttxnmc_clstr_ncbi\n";
print_in_square("BLAST Local Database and Clustering Sequences");
print "\ttxnmc_clstr_local\n";
print_in_square("Renaming Sequences");
print "\trnm_clstr\n";
print_in_square("Filtering Per Taxonomic level");
print "\tfiltr_per_txnmc_lvl\n";
print_in_square("Generating a Summary of Markers");
print "\tsummry_markers\n";
print_in_square("Converting Sequences to Rerun BLAST");
print "\tcnvrt_mrkrs\n";
print_in_square("Learning about the commands");
print "\thelp\n";
print_in_square("Exiting");
print "\texit\n";
print_in_square("Read ReadMe.txt file for detailed information about D4rwin V.1.");
my $parameter;
while (1) {
    
    my $parameter = prompt("");
    if ($parameter eq 'exit') {
print "Thank you for using D4rwin V.1! See you next time!\n";
        exit;  
    }

    



if ($parameter eq 'txnmc_db_only') {
    txnmc_db_only();
    print localtime() . " Would you like to enter another command?\n";
} elsif ($parameter eq 'clstr_only') {
clstr_only ();
      print localtime() . " Would you like to enter another command?\n";

} elsif ($parameter eq 'table_clstr') {
    
    table_clstr();
        print localtime() . " Would you like to enter another command?\n";

} elsif ($parameter eq 'txnmc_clstr_ncbi') {
    
    txnmc_clstr_ncbi();
        print localtime() . " Would you like to enter another command?\n";

}  elsif ($parameter eq 'reformat') {
    
    reformat();
        print localtime() . " Would you like to enter another command?\n";

    } elsif ($parameter eq 'filtr_per_txnmc_lvl') {
    
    filtr_per_txnmc_lvl();
        print localtime() . " Would you like to enter another command?\n";

}elsif ($parameter eq 'rnm_clstr') {
    
    rnm_clstr();
        print localtime() . " Would you like to enter another command?\n";

}elsif ($parameter eq 'txnmc_clstr_local') {
    
    txnmc_clstr_local();
        print localtime() . " Would you like to enter another command?\n";

}elsif ($parameter eq 'summry_markers') {
summry_markers();
print $log localtime() . " Done generating summary\n";
print localtime() . " Done generating summary\n";
    print localtime() . " Would you like to enter another command?\n";
}
elsif ($parameter eq 'blst_only') {
blst_only(); 
    print localtime() . " Would you like to enter another command?\n";
}
elsif ($parameter eq 'cnvrt_mrkrs') {
cnvrt_mrkrs(); 
    print localtime() . " Would you like to enter another command?\n";
}
elsif ($parameter eq 'help') {   
print "\t\t\t\t\t----\n";
print "\tDescription of the following commands:\n";
print_in_square("txnmc_db_only");
print "Downloads the sequences directly from NCBI, considering Taxonomic ID (txid) and the minimum number of base pairs.\nIt can be run either in batch mode or single-file mode.\n";
print_in_square("blst_only");
print "Automates the BLAST of sequences against a database using BLAST tools in either batch mode or single-file mode\n";
print_in_square("clstr_only");
print "Searches for sequences with high coverage, generates clusters based on high similarity and taxonomic coverage.\nCreates a table with clusters that have low coverage.\n";
print_in_square("reformat");
print "This command MUST be run inside the 'clusters' directory.\nConverts the sequences to the format >species_accession_number.\n";
print_in_square("txnmc_clstr_ncbi");
print "Executes a pipeline composed by the functions:txnmc_db_only, blst_only, clstr_only and reformat.\n";
print_in_square("txnmc_clstr_local");
print "Executes a pipeline composed by the functions:blst_only, clstr_only and reformat.\n";
print_in_square("rnm_clstr");
print "This command MUST be run inside the 'clusters' directory.\nRenames clusters based on a provided lists.\n";
print_in_square("filtr_per_txnmc_lvl");
print "This command MUST be run inside the 'clusters' directory.\nConcatenates all clusters of the same marker and retains the top longest sequence per species.\nCluster names should follow the format:ClusterNumber_*insertmarkername*.fasta.\nAlways check for misspellings in species due to GenBank errors.\nDefline MUST be:>species_acession.\n";
print_in_square("summry_markers");
print "This command MUST be run inside the 'clusters' directory.\nIt generates a table summarizing each species along with its accession number, sampled markers, and taxonomic coverage (multiple accession numbers can be stored per species).\n";
print_in_square("cnvrt_mrkrs");
print "This command MUST be run inside the 'clusters' directory.\nIt generates a table summarizing each species along with its accession number, sampled markers, and taxonomic coverage (multiple accession numbers can be stored per species).\n";
print_in_square("exit.");
print "Exits D4rwin Pipeline.\n";
print "\t\t\t\t\t----\n";
}
 elsif ($parameter ne 'txnmc_clstr_ncbi'|'txnmc_clstr_local'|'rnm_clstr'|'filtr_per_txnmc_lvl'|'clstr_only'|'txnmc_db_only'|'summry_markers'|'reformat'|'blst_only'|'cnvrt_mrkrs') {
 print "The command '$parameter' is not recognized.\nPlease check the syntax or ensure the command is available.\nProvide one of the following commands or type exit:\n";
print "\ttxnmc_db_only\n\tblst_only\n\tclstr_only\n\treformat\n\ttxnmc_clstr_ncbi\n\ttxnmc_clstr_local\n\trnm_clstr\n\tfiltr_per_txnmc_lvl\n\tsummry_markers\n\tcnvrt_mrkrs\n\thelp\n\texit\n";

} 
sub txnmc_db_only {
print localtime() . " Starting Taxonomic Database Assembling Phase\n";
print $log localtime() . " Starting Taxonomic Database Assembling Phase\n";
use strict;
use Time::HiRes qw(sleep); 
use IO::Handle;  


STDOUT->autoflush(1);

my $ncbi_db_type;
my $Strict_search = '';  
my $txids_combined;
my $txids;
my $folder_name;
my $length;
my $ncbi_db_type;
my $excluded_txids;
 my @excluded_txid_list;
 my $txids_excluded_combined;
 my  $new_exclude_records;
 my   $exclude_records;
 my $new_exclude_srch;
my $exclude_srch;
my  $new_include_srch;
my $include_srch;
my $new_Include_strict;
my $Include_strict;
my $cmd;
my $batch_size =+0;
my $addition_ncbi;
my $delete_ncbi=+0;
open my $cfg, '<', "./D4rwin_cfg.txt" or die "Cannot open D4rwin_cfg.txt: $!";

while (my $line = <$cfg>) {
    
    chomp $line;
    if ($line =~ /File Name=(.*);/) {
        $folder_name = $1;  
        $folder_name =~ s/\s+/_/g;
    }

    
if ($line =~ /Taxonomic Identification of Interest \(Txids\)=([\d+;]+)/) {
        $txids  = "__" . $1;  
        $txids  =~ s/;/\[Organism\]_/g;
        $txids  =~ s/__/txid/g;
    
        my @txid_list  = split(/_/, $txids ); 
        
        $txids_combined  = join(" OR txid", @txid_list );  
    
}
 if ($line =~ /Length=(.*);/) {
   $length="$1";
}     

 if ($line =~ /NCBI Database Type=(.*);/) {
   $ncbi_db_type="$1";
}
 if ($line =~ /Exclude Txids=Yes;([\d+;]+)/) {
        $excluded_txids = "_".$1;  
        $excluded_txids =~ s/;/\[Organism\]_/g;
 @excluded_txid_list = split(/_/, $excluded_txids); 
             $txids_excluded_combined = join(" NOT txid",@excluded_txid_list);

        }
  if ($line =~ /Exclude Records=Yes;([\w+\.\d\s]+);/) {
   $exclude_records="$1";
          $exclude_records=~ s/\s+/ NOT /g;
   $new_exclude_records="NOT "."$exclude_records";

        }
 if ($line =~ /Targeted Search=Yes;([\w\s-]+);/) {
   $Include_strict="$1";
          $Include_strict=~ s/\s+/ AND /g;
             $Include_strict=~ s/\_/ /g;
          $new_Include_strict="AND ".$Include_strict;
        
        }
          if ($line =~ /Flexible Search=Yes;([\w+\s-]+);/) {
   $include_srch="\($1\)";
          $include_srch=~ s/\s+/ OR /g;
                    $include_srch=~ s/\_/ /g;
                    $new_include_srch="AND ".$include_srch;
        }
         if ($line =~ /Exclude Terms=Yes;([\w+\s-]+);/) {
   $exclude_srch="$1";
          $exclude_srch=~ s/\s+/ NOT /g;
                    $exclude_srch=~ s/_/ /g;

   $new_exclude_srch="NOT "."$exclude_srch";


        }
 if ($line =~ /Additional NCBI Search Terms=(.*);/) {
   $addition_ncbi="$1";
}
 if ($line =~ /Batch Size=(\d+);/) {
   $batch_size="$1";
}
 if ($line =~ /Delete NCBI Batches After Assembling Database Phase=Yes;/) {
  $delete_ncbi=+1;
}
}
close $cfg;


print $log localtime() . " Downloading taxonomic database\n";
print localtime() . " Downloading taxonomic database\n";
use POSIX qw(ceil);  


my $cmd = "esearch -db $ncbi_db_type -query \"$txids_combined $txids_excluded_combined $new_exclude_records $new_Include_strict $new_include_srch $new_exclude_srch $addition_ncbi $length\" | efetch -format acc >$folder_name\.list.txt";
$cmd =~ s/\s+/ /g; 
 print $log localtime() . " NCBI command line used: $cmd\n";
       print localtime() . " NCBI command line used: $cmd\n";
system ($cmd);
my @accs;
open my $file_hd, '<', "./$folder_name".".list.txt" or die "Cannot open ./$folder_name\.list.txt: $!";
while (my $line = <$file_hd>) {
    if ($line =~ /(\w+\.\d+)\n/) {       
        push(@accs, $1);
    }}


       
my $counter=0;
  
 my $total_batch=scalar(@accs);


my $retry_delay;
my @retry_delays = (300,600,900,3600);                 
my $max_retries = @retry_delays;                
my $timeout = 3600;   
my $total_steps = ceil($total_batch / $batch_size);
  print $log localtime() . " Downloading $total_batch sequences from NCBI database in $total_steps batches\n";
print localtime() . " Downloading $total_batch sequences from NCBI database in $total_steps batches\n";
for (my $i = 0; $i < @accs; $i += $batch_size) {
    
    my @batch = @accs[$i .. ($i + $batch_size - 1 < $#accs ? $i + $batch_size - 1 : $#accs)];
    my $query = join(" OR ", @batch);
    my $start = $i + 1;
    my $end = $i + @batch;
   
            $counter++;
        
my $cmd3 = "esearch -db $ncbi_db_type -query \"$query\" | efetch -format fasta >  batch\_$start\_$end.fasta  && cat batch\_$start\_$end.fasta >> $folder_name.fasta";
    $cmd3 =~ s/\s+/ /g;  
   my $success;  
    my $attempt = 0;  

use Time::HiRes qw(alarm);  

while ($attempt < $max_retries && !$success) {
    my $pid = fork();

    if (!defined $pid) {
        die "Failed to fork: $!";
    } elsif ($pid == 0) {
        
        exec($cmd3) or die "Failed to execute $cmd3: $!";
    } else {
        
       

        eval {
            local $SIG{ALRM} = sub { die "Timeout reached\n" };  
            alarm($timeout);  

            
            my $wait_result = waitpid($pid, 0);

            alarm(0);  

            if ($wait_result == $pid) {
                my $exit_status = $?;  

                if ($exit_status != 0) {
 
                print "\n".localtime() . " Error encountered while fetching batch:" . $start . ":" . $end . " with the following accession numbers: $query\n";                    
                print $log localtime() . " Error encountered while fetching batch:" . $start . ":" . $end . " with the following accession numbers: $query\n";                    

                    $attempt++;
                                             my $retry_delay = $retry_delays[$attempt-1];
                                                                my $minutes=$retry_delay/60;
  
                 print "\n".localtime() . " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";
                 print $log localtime() . " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";

                            sleep ($retry_delay);

                } else {
                    $success = 1; 
                 print $log localtime() . " Successfully fetched batch:" . $start . ":" . $end . " from NCBI database\n";
   
                if ($delete_ncbi eq 1) {
                        unlink "./batch\_$start\_$end.fasta";
                    }
             my $bar_length = 50;  
my $filled_length = int(($counter / $total_steps) * $bar_length);  
my $bar = '#' x $filled_length . '-' x ($bar_length - $filled_length);  
my $percent = int(($counter / $total_steps) * 100);

            print "\r[$bar] $counter/$total_steps \($percent%\) batches fetched";
                      sleep(1);
               
                }
                
            } else {
            }
        };

        if ($@) {
            
              my $timeout_min=$timeout/60;     
            system("pkill -9 -g " . getpgrp($pid));  
                        waitpid($pid, 0);    
            $attempt++;           
                         my $retry_delay = $retry_delays[$attempt-1];  
                                            my $minutes=$retry_delay/60;

            print "\n".localtime() . " Attempt $attempt of $max_retries of fetching batch:" . $start . ":" . $end . " from NCBI database stopped due to timeout $timeout_min minutes\n";
                        print "\n". localtime() . " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";
            print $log localtime() . " Attempt $attempt of $max_retries of fetching batch:" . $start . ":" . $end . " from NCBI database stopped due to timeout $timeout_min minutes\n";
                        print $log localtime() . " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";

        sleep ($retry_delay);
        }
    }
}

if ($attempt >= $max_retries) {
                print "\n". localtime() ." Maximum retry attempts reached. Skipping this batch.\n";
                    print $log localtime() ." Maximum retry attempts reached. Skipping this batch.\n";
next;
     }

            
}
print $log localtime() . " Done downloading sequences from NCBI database\n";
print "\n".localtime() . " Done downloading sequences from NCBI database\n";

unlink "./$folder_name".".list.txt";
print localtime() . " Completed Taxonomic Database Assembling Phase\n";
print $log localtime() . " Completed Taxonomic Database Assembling Phase\n";


}
sub blst_only {
open my $cfg, '<', "./D4rwin_cfg.txt" or die "Cannot open D4rwin_cfg.txt: $!";
   my $folder_name;
    my $query_cvrg;
   my $evalue;
   my $Threads;
   my $db_type;
   my $dust;
   my $orientation;
   my $dust2=+0;
my $orientation2=+0;
my $cmd;
my $addition_blast;
my $blast_tool;
my $blast_flag=+0;
my $batch_size;
my $delete_flag=+0;
use File::Basename; 
use IO::Handle;  


STDOUT->autoflush(1);

while (my $line = <$cfg>) {
     if ($line =~ /File Name=(.*);/) {
        $folder_name = $1;  
        $folder_name =~ s/\s+/_/g;
    }

  if ($line =~ /E-value=(.*);/) {
   $evalue="$1";
} if ($line =~ /Query Coverage=(.*);/) {
   $query_cvrg="$1";
        
}
 if ($line =~ /Threads=(.*);/) {
   $Threads="$1";
}
if ($line =~ /BLAST Database Type=(.*);/) {
   $db_type="$1";
}
 if ($line =~ /Dust=(\w+);/) {
   $dust=lc($1);
      $dust2=0;
}    
 if ($line =~ /Dust=;\n/) {
   $dust2=1;
}    
 if ($line =~ /Strand=(\w+);/) {
   $orientation=lc($1);
           $orientation2=0;
} 
if ($line =~ /Strand=();\n/) {
   $orientation2=1;
}
 if ($line =~ /Additional BLAST Parameters=(.*);/) {
   $addition_blast="$1";
}
 if ($line =~ /BLAST Tool=(\w+);\n/) {
   $blast_tool=lc($1);
}
 if ($line =~ /Executes BLAST Sequences Per Batches=Yes;/) {
   $blast_flag=+1;
}
 if ($line =~ /Delete Batches After BLAST Stage=Yes;/) {
   $delete_flag=+1;
}
}
close $cfg;

use Time::HiRes qw(alarm);  
use File::Basename; 
print localtime() . " Starting BLAST Phase\n";
print $log localtime() . " Starting BLAST Phase\n";
system ("makeblastdb -in $folder_name.fasta -dbtype $db_type");

if ($blast_flag eq 1){

my @fasta_files2 = grep { $_ ne "$folder_name.fasta" } glob("*.fasta");
my $total_steps=scalar(@fasta_files2);
my $retry_delay;
my @retry_delays = (600,900,1800);   
my $max_retries =@retry_delays;                 
my $timeout =43200;   
my $cmd3;
my @fasta_files2 = map { s/\.fasta$//r } grep { $_ ne "$folder_name.fasta" } glob("*.fasta");

my $counter=0;
print localtime() . " Executing BLAST for $total_steps batches of sequences\n";
print $log localtime() . " Executing BLAST for $total_steps batches of sequences\n";
foreach my $file2 (@fasta_files2) {;

$counter++;

my $directory = './'; 

if ($dust2 && $orientation2 eq 1) {
     $cmd3 = "$blast_tool -query $file2\.fasta -db $folder_name.fasta -outfmt \"6 qseqid sseqid pident length evalue qcovs qcovhsp\" -out $file2.ouftl.txt -evalue $evalue -qcov_hsp_perc $query_cvrg $addition_blast -num_threads $Threads && cat $file2.ouftl.txt>>$folder_name.ouftl.txt";
$cmd3 =~ s/\s+/ /g; 
;}
       else {
    
    
    $cmd3 = "$blast_tool -query $file2.fasta -db $folder_name.fasta -outfmt \"6 qseqid sseqid pident length evalue qcovs qcovhsp\" -dust $dust -out $file2.ouftl.txt -strand $orientation -evalue $evalue -qcov_hsp_perc $query_cvrg $addition_blast -num_threads $Threads && cat $file2.ouftl.txt>>$folder_name.ouftl.txt";
$cmd3 =~ s/\s+/ /g; 
}

    my $success;  
    my $attempt = 0;  

while ($attempt < $max_retries && !$success) {
    my $pid = fork();

    if (!defined $pid) {
        die "Failed to fork: $!";
    } elsif ($pid == 0) {
        
        exec($cmd3) or die "Failed to execute $cmd3: $!";
    } else {
         

        eval {
            local $SIG{ALRM} = sub { die "Timeout reached\n" };  
            alarm($timeout);  

            my $wait_result = waitpid($pid, 0);

            alarm(0);  

            if ($wait_result == $pid) {
                my $exit_status = $?;  

                if ($exit_status != 0) {
                    print "\n".localtime() . " Error encountered while running BLAST: $file2\n";
                    print $log localtime() . " Error encountered while running BLAST: $file2\n";
                    
                    $attempt++;
                    my $retry_delay = $retry_delays[$attempt-1];
                    my $minutes=$retry_delay/60;
  
                 print "\n".localtime() .  " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";
                 print $log localtime() .  " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";

                            sleep ($retry_delay);

                } else {
                    $success = 1;  
                             print $log localtime() .  " Successfully BLAST $file2\n";

    my $bar_length = 50;  
        my $filled_length = int(($counter / $total_steps) * $bar_length);  
        my $bar = '#' x $filled_length . '-' x ($bar_length - $filled_length);  
        my $percent = int(($counter / $total_steps) * 100);
        
        
            print "\r[$bar] $counter/$total_steps \($percent%\) batches";
                    sleep(1);
                    
                    if ($delete_flag eq 1) {
                        system("rm $file2.*");
                    }
                }
            } else {
            }
        };

        if ($@) {
            
              my $timeout_min=$timeout/3600;     
            system("pkill -9 -g " . getpgrp($pid));  
                        waitpid($pid, 0);    
            $attempt++;           
                         my $retry_delay = $retry_delays[$attempt-1];  
                                            my $minutes=$retry_delay/60;

            print "\n".localtime() .  " Attempt $attempt of $max_retries to blast $file2 stopped due to timeout of $timeout_min hours\n";
                        print "\n".localtime() .  " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";
            print $log localtime() .  " Attempt $attempt of $max_retries to blast $file2 stopped due to timeout of $timeout_min hours\n";
                        print $log localtime() .  " Retrying in $minutes minutes. (Attempt $attempt of $max_retries)\n";

        sleep ($retry_delay);
        }
    }
}

if ($attempt >= $max_retries) {
    print "\n".localtime() . " Maximum retry attempts reached.\n";
    print $log localtime() .  " Maximum retry attempts reached\n";
    print "\n".localtime() .  " A problem occurred while running BLAST: $file2 (skipping this batch)\n";
    print $log localtime() .  " A problem occurred while running BLAST: $file2 (skipping this batch)\n";
next;
}


}
				print "\n".localtime() .  " Completed BLAST Phase\n";
                print $log localtime() .  " Completed BLAST Phase\n";
}
if ($blast_flag eq 0){

my $directory = './';

if ($dust2 && $orientation2 eq 1) {
     $cmd = "$blast_tool -query $folder_name.fasta -db $folder_name.fasta -outfmt \"6 qseqid sseqid pident length evalue qcovs qcovhsp\" -out $folder_name.ouftl.txt -evalue $evalue -qcov_hsp_perc $query_cvrg $addition_blast -num_threads $Threads";
$cmd =~ s/\s+/ /g;
}   

else {

     $cmd = "$blast_tool -query $folder_name.fasta -db $folder_name.fasta -outfmt \"6 qseqid sseqid pident length evalue qcovs qcovhsp\" -dust $dust -strand $orientation -out $folder_name.ouftl.txt -evalue $evalue -qcov_hsp_perc $query_cvrg $addition_blast -num_threads $Threads";
$cmd =~ s/\s+/ /g;

}
 my $exit_code = system($cmd);
    
    
    if ($exit_code != 0) {
        
        my $status = $?;
        warn "Command failed with exit code $status: $cmd\n";
    }

 if ($exit_code != 1) {
        
        my $status = $?;
 				print "\n".localtime() .  " Completed BLAST Phase\n";
                print $log localtime() .  " Completed BLAST Phase\n";
    }}

}

sub reformat {
use strict;
use File::Basename;
use File::Copy;


print $log localtime() . " Formatting sequences to the format >Genus_species_accessionNumber\n";
print localtime() . " Formatting sequences to the format >Genus_species_accessionNumber\n";


my $directory = './';


opendir(my $dh, $directory) or die "Can't open directory: $directory\n";


my @refo_clsts = grep { /\.fasta$/ && -f "$directory/$_" } readdir($dh);
closedir($dh);

foreach my $newfor (@refo_clsts) {
    my $input_file = "$directory/$newfor";
    my $output_file = "$directory/$newfor\_";

    open my $input_fh, '<', $input_file or die "Can't open input file: $input_file\n";
    open my $output_fh, '>', $output_file or die "Can't open output file: $output_file\n";

    
    while (my $line = <$input_fh>) {
        chomp $line;
$line =~ s/^>(\w+)_(\w+\.\d+)/>$1$2/;

        
        if ($line =~ /^>(\w+\.\d+)\s+(\w+)\s+(\w+)\s+x\s+(\w+)\s+(\w+)/) {
            my $accession = $1;

            my $spp1 = "$2_$3";  
            my $spp2 = "$4_$5";  

            
            print $output_fh ">$spp1\_x\_$spp2\_$accession\n";
        }

        
        elsif ($line =~ /^>(\w+\.\d+)\s+(\w+)\s+(\w+)/) {
            my $accession = $1;

            my $spp = "$2_$3";   

            
            print $output_fh ">$spp\_$accession\n";
        }

        
        else {
            print $output_fh "$line\n";  
        }
    }

    
    rename($output_file, $input_file) or die "Renamed Phase failed\n";

    
    close $input_fh;
    close $output_fh;
}

print $log localtime() . " Finished formatting sequences to the format >Genus_species_accessionNumber\n";
print localtime() . " Finished formatting sequences to the format >Genus_species_accessionNumber\n";



}
sub filtr_per_txnmc_lvl {
use strict;
use File::Spec;
use File::Copy;
use List::Util qw(all);
use File::Path qw(make_path);
my $taxonomic_lvl=0;
my $end;
my $txnmc_ncbi_flag=0;
my $txnmc_name;
my $concat_flag=0;
my %genus_info;
my $level;

open my $cfg, '<', "./D4rwin_cfg.txt" or die "Cannot open D4rwin_cfg.txt: $!";

while (my $line = <$cfg>) {
    if ($line =~ /Top Sequences Per Taxonomic Level=(\d+);/) {
        $end = $1-1;  
}
   if ($line =~ /Taxonomic Level of Choice=(Species);/) {
        $taxonomic_lvl=1; 
		$level=$1;
}

   if ($line =~ /Taxonomic Level of Choice=(Genus);/) {
        $taxonomic_lvl=2; 
        		$level=$1;
}
   if ($line =~ /Taxonomic Level of Choice=(Family);/) {
        $taxonomic_lvl=3; 
        		$level=$1;
}
   if ($line =~ /Taxonomic Level of Choice=(Order);/) {
        $taxonomic_lvl=4;
        		$level=$1;
}
   if ($line =~ /Taxonomic Level of Choice=(Class);/) {
        $taxonomic_lvl=5;
        		$level=$1;
}
   if ($line =~ /Concatenate Clusters From The Same Marker Prior to Filtering=(Yes);/) {
        $concat_flag =1;  
}
   $txnmc_ncbi_flag = 1 if $line =~ /Use NCBI Taxonomic Table=Yes;/;
      $txnmc_name= $1 if $line =~ /Taxonomic Identification of Interest \(Txids\)=([\d+;]+)/;

}
close $cfg;
my @txnmc_names = split(/;/, $txnmc_name);
if ($taxonomic_lvl eq 1){
one_per_level();
}
if ($taxonomic_lvl gt 1){
if ($txnmc_ncbi_flag eq 1) {
 print  localtime() . " Downloading NCBI taxonomic table.\n";
print  $log localtime() . " Downloading NCBI taxonomic table.\n";
my $ncbifile = "./NCBI_taxonomy_summary.tsv"; 

if (-e $ncbifile) {
    unlink($ncbifile);
}
open my $fh_filtered, '>', './NCBI_taxonomy_summary.tsv' or die "Cannot open NCBI_taxonomy_summary.tsv: $!\n";
print $fh_filtered "TxId\tScientific Name\tGenus\tFamily\tOrder\tClass\n";
close $fh_filtered;
foreach my $var_txid (@txnmc_names) {
    system("esearch -db taxonomy -query \"txid$var_txid\[Subtree\]\" | efetch -format xml | xtract -pattern Taxon -tab \"\t\" -element TaxId -element ScientificName -block LineageEx/Taxon -if Rank -equals genus -element ScientificName -block LineageEx/Taxon -if Rank -equals family -element ScientificName -block LineageEx/Taxon -if Rank -equals order -element ScientificName -block LineageEx/Taxon -if Rank -equals class -element ScientificName >> NCBI_taxonomy_summary.tsv");
}


print  localtime() . " Done NCBI taxonomic table.\n";
print $log localtime() . " Done NCBI taxonomic table.\n";

    open my $fh_filtered, './NCBI_taxonomy_summary.tsv' or die "Cannot open ./NCBI_taxonomy_summary.tsv: $!";

    while (my $line = <$fh_filtered>) {
        chomp $line;
        my @fields = split(/\t/, $line);
        
        
        my ($spp_id, $genus_id, $family_id, $order_id, $class_id) = @fields[1, 2, 3, 4, 5];  
        
        $genus_info{$spp_id} = {
            genus  => $genus_id,
            family => $family_id,
            order  => $order_id,
            class  => $class_id,
        };
    }
    close $fh_filtered;
}
if ($txnmc_ncbi_flag eq 0) {
    open my $fh_filtered, './ALL_taxonomy_summary.tsv' or die "Cannot open ./ALL_taxonomy_summary.tsv: $!";

    while (my $line = <$fh_filtered>) {
        chomp $line;
        my @fields = split(/\t/, $line);
        
        
        my ($spp_id, $genus_id, $family_id, $order_id, $class_id) = @fields[4,3,2,1,0];  

        
        $genus_info{$spp_id} = {
            genus  => $genus_id,
            family => $family_id,
            order  => $order_id,
            class  => $class_id,
        };
    }
    close $fh_filtered;
}

my %unique_genus;

foreach my $spp_id (keys %genus_info) {
    my $genus = $genus_info{$spp_id}->{genus};

    unless (exists $unique_genus{$genus}) {
        $unique_genus{$genus} = {
            family => $genus_info{$spp_id}->{family},
            order  => $genus_info{$spp_id}->{order},
            class  => $genus_info{$spp_id}->{class},
        };
    }
}
my $finaldir ='./';
my $source_dir = './';  

my $accs;
opendir(my $dh2, $finaldir) or die "Cannot open directory $finaldir\n";
my @clusters_filtered = grep { /\.fasta$/ && -f File::Spec->catfile($source_dir, $_) } readdir($dh2);
closedir($dh2);
foreach my $clusters (@clusters_filtered) {
    my $input_file = File::Spec->catfile($source_dir, $clusters);
    my $output_file = File::Spec->catfile($finaldir,"Top_Sqs_per_$level\_".$clusters);

    open my $cluster_old, '<', $input_file or die "Cannot open file $input_file\n";
    open my $cluster_new, '>', $output_file or die "Cannot open file $output_file\n";

    local $/ = ">";
        while (my $record = <$cluster_old>) {
        chomp $record;
        next if !$record;
        my ($header, $sequence) = split /\n/, $record, 2;
        next unless $sequence; 
        foreach my $genus (keys %unique_genus) { 
            if ($header =~ /$genus\_.*/) {  
             if ($header =~ /$genus\_\w+_x_\w+_\w+_(\w+\.\d+)/) {
             $accs = $1;
     next;
        }
        elsif ($header =~ /$genus\_\w+_(\w+\.\d+)/) {
             $accs = $1;
}
            if ($taxonomic_lvl eq 2){
         if (defined $genus && $genus eq '') {
    next; 
}
         if ($end >= 0) {
                print  $cluster_new ">$genus\_$header\n$sequence\n";
                
                }}
                            if ($taxonomic_lvl eq 3){
                if ($unique_genus{$genus}->{family}) {  

            if ($end eq 0){
            print  $cluster_new ">$unique_genus{$genus}->{family}\_$unique_genus{$genus}->{family}\_$accs\n$sequence\n";

            }
            elsif ($end eq 1)  {
  print  $cluster_new ">$unique_genus{$genus}->{family}\_$header\n$sequence\n";

                }}
                }
                                            if ($taxonomic_lvl eq 4){
                                                            if ($unique_genus{$genus}->{order}) {  

            if ($end eq 0){
            
            print  $cluster_new ">$unique_genus{$genus}->{order}\_$unique_genus{$genus}->{order}\_$accs\n$sequence\n";

            }
            else {
       

                print  $cluster_new ">$unique_genus{$genus}->{order}\_$header\n$sequence\n";
                }
                }}
                                            if ($taxonomic_lvl eq 5){
                                                            if ($unique_genus{$genus}->{class}) {  

            if ($end eq 0){
            print  $cluster_new ">$unique_genus{$genus}->{class}\_$unique_genus{$genus}->{class}\_$accs\n$sequence\n";

            }
            else {
                print  $cluster_new ">$unique_genus{$genus}->{class}\_$header\n$sequence\n";
                }
                }}
            }
        }
    }


    close $cluster_old;
    close $cluster_new;
}
if ($end >= 0){
more_than_two_per_lvl();
}
}

sub one_per_level{
my $end2=$end+1;


print $log localtime() . " Filtering the top $end2 longest sequences for each taxon in $level level\n";
print localtime() . " Filtering the top $end2 longest sequences for each taxon in $level level\n";
my $finaldir = "0.Clusters_filtered_per_Species/";

unless (-d $finaldir) {
    eval { make_path($finaldir); };
    if ($@) {
        die "Failed to create directory $finaldir\n";
    }
}

my $source_dir = './';
if ($concat_flag eq 1){
opendir(my $dh, $source_dir) or die "Cannot open directory $source_dir\n";
my @names = grep { /\.fasta$/ && -f File::Spec->catfile($source_dir, $_) } readdir($dh);
closedir($dh);


my %seen;
my @unique_array = grep { !$seen{$_}++ } map {
    my ($name) = $_ =~ /_(\w+)\.fasta$/;
    $name;
} @names;


my $batch_size = 10;  

foreach my $var (@unique_array) {
    my @input_files = glob("$source_dir/*_$var.fasta"); 
    my $output_file = "$finaldir/ALL_$var.fasta";
    
    
    for (my $i = 0; $i < @input_files; $i += $batch_size) {
        my @batch_files = @input_files[$i .. $i + $batch_size - 1];
        my $batch_input_files = join(' ', @batch_files);

        
        my $command = "cat $batch_input_files >> $output_file";
        system($command) == 0 or warn "System call failed: $!"; #
    }
}

opendir(my $dh2, $finaldir) or die "Cannot open directory $finaldir\n";
my @clusters_filtered = map { s/ALL_//r } grep { /\.fasta$/ && -f File::Spec->catfile($finaldir, $_) } readdir($dh2);
closedir($dh2);


foreach my $clusters (@clusters_filtered) {
    my $input_file = File::Spec->catfile($finaldir, "ALL_$clusters"); 
    my $output_file = File::Spec->catfile($finaldir, "$clusters");

    open my $cluster_old, '<', $input_file or die "Cannot open filqe $input_file\n";
    open my $cluster_new, '>>', $output_file or die "Cannot open fileqq $output_file\n";

    local $/ = ">";  

    my %data;
    while (my $record = <$cluster_old>) {
        chomp $record;
        next unless $record;

        
        my ($header, $sequence) = split /\n/, $record, 2;
        next unless $sequence;
        $sequence =~ s/\s+//g;  

        
        if ($header =~ /^>(\w+_\w+_x_\w+_\w+)_(\w+\.\d+)/) {
            my ($species, $accession) = ($1, $2);
            $data{$species}{$accession} = $sequence;
        }
        
        elsif ($header =~ /(\w+_\w+)_(\w+\.\d+)/) {
            my ($species, $accession) = ($1, $2);
            $data{$species}{$accession} = $sequence;
        }
    }
    close $cluster_old;

my %top_sequences;

foreach my $species (keys %data) {
    my @sequences;

    
    foreach my $accession (keys %{$data{$species}}) {
        my $sequence = $data{$species}{$accession};
        if ($sequence) {  
            push @sequences, { seq => $sequence, acc => $accession };
        }
    }

    
    my @sorted_sequences = sort { length($b->{seq}) <=> length($a->{seq}) } @sequences;
my $limit=$end+1;
    
    if (@sorted_sequences > $limit) {
        $top_sequences{$species} = [ @sorted_sequences[0..$end] ];  
    } elsif (@sorted_sequences > 0) {
        $top_sequences{$species} = \@sorted_sequences;  
    } else {
        $top_sequences{$species} = [];  
    }
}


foreach my $species (sort keys %top_sequences) {
    foreach my $seq_info (@{$top_sequences{$species}}) {
        if ($seq_info->{seq}) {  
            print $cluster_new ">$species\_$seq_info->{acc}\n$seq_info->{seq}\n";
        }
    }
}

    
   unlink $finaldir . "ALL_$clusters";

}}
if ($concat_flag eq 0){
opendir(my $dh2, $source_dir) or die "Cannot open directory $finaldir\n";
my @clusters_filtered =grep { /\.fasta$/ && -f File::Spec->catfile($source_dir, $_) } readdir($dh2);
closedir($dh2);


foreach my $clusters (@clusters_filtered) {
    my $input_file = File::Spec->catfile($source_dir, "$clusters");
    my $output_file = File::Spec->catfile($finaldir, "$clusters");

    open my $cluster_old, '<', $input_file or die "Cannot open file $input_file\n";
    open my $cluster_new, '>>', $output_file or die "Cannot open file $output_file\n";

    local $/ = ">";  

    my %data;
    while (my $record = <$cluster_old>) {
        chomp $record;
        next unless $record;

        
        my ($header, $sequence) = split /\n/, $record, 2;
        next unless $sequence;
        $sequence =~ s/\s+//g;  

        
        if ($header =~ /^>(\w+_\w+_x_\w+_\w+)_(\w+\.\d+)/) {
            my ($species, $accession) = ($1, $2);
            $data{$species}{$accession} = $sequence;
        }
        
        elsif ($header =~ /(\w+_\w+)_(\w+\.\d+)/) {
            my ($species, $accession) = ($1, $2);
            $data{$species}{$accession} = $sequence;
        }
    }
    close $cluster_old;

my %top_sequences;

foreach my $species (keys %data) {
    my @sequences;

    
    foreach my $accession (keys %{$data{$species}}) {
        my $sequence = $data{$species}{$accession};
        if ($sequence) {  
            push @sequences, { seq => $sequence, acc => $accession };
        }
    }

    
    my @sorted_sequences = sort { length($b->{seq}) <=> length($a->{seq}) } @sequences;
my $limit=$end+1;
    
    if (@sorted_sequences > $limit) {
        $top_sequences{$species} = [ @sorted_sequences[0..$end] ];  
    } elsif (@sorted_sequences > 0) {
        $top_sequences{$species} = \@sorted_sequences;  
    } else {
        $top_sequences{$species} = [];  
    }
}


foreach my $species (sort keys %top_sequences) {
    foreach my $seq_info (@{$top_sequences{$species}}) {
        if ($seq_info->{seq}) {  
            print $cluster_new ">$species\_$seq_info->{acc}\n$seq_info->{seq}\n";
        }
    }
}

    
}}
print $log localtime() . " Done filtering the top $end2 longest sequences for each taxon in $level level\n";
print localtime() . " Done filtering the top $end2 longest sequences for each taxon in $level level\n";
}
sub more_than_two_per_lvl{
my $end2=$end+1;
my $finaldir = "0.Filtered_per_$level/";

unless (-d $finaldir) {
    eval { make_path($finaldir); };
    if ($@) {
        die "Failed to create directory $finaldir\n";
    }
}

print $log localtime() . " Filtering the top $end2 longest sequences for each taxon in $level level\n";
print localtime() . " Filtering the top $end2 longest sequences for each taxon in $level level\n";


my $source_dir = './';



opendir(my $dh2, $source_dir) or die "Cannot open directory $finaldir\n";
my @clusters_filtered =grep { /^Top_Sqs_per_$level\_.*\.fasta$/ && -f File::Spec->catfile($source_dir, $_) } readdir($dh2);
closedir($dh2);


foreach my $clusters (@clusters_filtered) {
    my $input_file = File::Spec->catfile($source_dir, "$clusters");
    my $output_file = File::Spec->catfile($finaldir, "$clusters");

    open my $cluster_old, '<', $input_file or die "Cannot open file $input_file\n";
    open my $cluster_new, '>', $output_file or die "Cannot open file $output_file\n";

    local $/ = ">";  

    my %data;
    while (my $record = <$cluster_old>) {
        chomp $record;
        next unless $record;

        
        my ($header, $sequence) = split /\n/, $record, 2;
        next unless $sequence;
        $sequence =~ s/\s+//g;  

        
        if ($header =~ /^>(\w+)?_(\w+_\w+_x_\w+_\w+_\w+\.\d+)/) {
            my ($species, $accession) = ($1, $2);
            $data{$species}{$accession} = $sequence;
        }
        
        elsif ($header =~ /(\w+)?_(\w+_\w+_\w+\.\d+)/) {
            my ($species, $accession) = ($1, $2);
            $data{$species}{$accession} = $sequence;
        }
    }
    close $cluster_old;

my %top_sequences;

foreach my $species (keys %data) {
    my @sequences;

    
    foreach my $accession (keys %{$data{$species}}) {
        my $sequence = $data{$species}{$accession};
        if ($sequence) {  
            push @sequences, { seq => $sequence, acc => $accession };
        }
    }

    
    my @sorted_sequences = sort { length($b->{seq}) <=> length($a->{seq}) } @sequences;
my $limit=$end+1;
    
    if (@sorted_sequences > $limit) {
        $top_sequences{$species} = [ @sorted_sequences[0..$end] ];  
    } elsif (@sorted_sequences > 0) {
        $top_sequences{$species} = \@sorted_sequences;  
    } else {
        $top_sequences{$species} = [];  
    }
}


foreach my $species (sort keys %top_sequences) {
    foreach my $seq_info (@{$top_sequences{$species}}) {
        if ($seq_info->{seq}) {  
            print $cluster_new ">$species\_$seq_info->{acc}\n$seq_info->{seq}\n";
        }
    }
}
 close$cluster_new;
}
print $log localtime() . " Done filtering the top $end2 longest sequences for each taxon in $level level\n";
print localtime() . " Done filtering the top $end2 longest sequences for each taxon in $level level\n";
 system("rm Top_Sqs_*.fasta");

}

}
sub rnm_clstr {

use strict;

use File::Copy;

use File::Path qw(make_path);


print $log localtime() . " Renaming sequences using a list.txt file containing the new File Names\n";
print localtime() . " Renaming sequences using a list.txt file containing the new File Names\n";
use strict;
use File::Spec;
use File::Copy;          
use File::Path qw(make_path);


my $source_dir = './';        
my $output_dir = './0.Renamed_Clusters';  
my $list_file = 'list.txt';   


unless (-d $output_dir) {
    make_path($output_dir) or die "Failed to create directory $output_dir\n";
}


opendir(my $dh, $source_dir) or die "Cannot open directory $source_dir\n";


my @fasta_files = sort grep { /\.fasta$/ && -f File::Spec->catfile($source_dir, $_) } readdir($dh);


closedir($dh);


open my $list_fh, '<', $list_file or die "Cannot open $list_file\n";
my @list_names;


while (my $line = <$list_fh>) {
    chomp($line);
    push @list_names, $line;
}
close($list_fh);


foreach my $index (0 .. $#fasta_files) {
    my $fasta_file = $fasta_files[$index];
    my $list_name = $list_names[$index];

    
    if (defined $list_name) {
        
        my $output_file = File::Spec->catfile($output_dir, "$list_name.fasta");
        
        
        copy(File::Spec->catfile($source_dir, $fasta_file), $output_file) or die "Copy failed\n";
    }
}

print $log localtime() . " Successfully completed renaming sequences\n";
print localtime() . " Successfully completed renaming sequences\n";

}
sub txnmc_clstr_local{
	 blst_only();
    clstr_only();
}
sub summry_markers{
use strict;
use File::Basename;

open my $cfg, '<', "./D4rwin_cfg.txt" or die "Cannot open D4rwin_cfg.txt: $!";
my $txnmc_ncbi_flag=0;
my $txnmc_name;
my $txnmc_names;
print $log localtime() . " Generating summary of the sequences and taxonomic coverage sampled\n";
print localtime() . " Generating summary of the sequences and taxonomic coverage sampled\n";

while (my $line = <$cfg>) {
   
   $txnmc_ncbi_flag = 1 if $line =~ /Use NCBI Taxonomic Table=Yes;/;
      $txnmc_name= $1 if $line =~ /Taxonomic Identification of Interest \(Txids\)=([\d+;]+)/;
      $txnmc_name= $1 if $line =~ /Taxonomic Identification of Interest \(Txids\)=([\d+;]+)/;
}
close $cfg;
my @txnmc_names = split(/;/, $txnmc_name);

if  ($txnmc_ncbi_flag eq 1){
print  localtime() . " Downloading NCBI Taxonomic Table.\n";
print  $log localtime() . " Downloading NCBI Taxonomic Table.\n";
my $ncbifile = "./NCBI_taxonomy_summary.tsv";

if (-e $ncbifile) {
    unlink($ncbifile);
}
open my $fh_filtered, '>', './NCBI_taxonomy_summary.tsv' or die "Cannot open NCBI_taxonomy_summary.tsv: $!\n";
print $fh_filtered "TxId\tScientific Name\tGenus\tFamily\tOrder\tClass\n";
close $fh_filtered;
foreach my $var_txid (@txnmc_names) {
    system("esearch -db taxonomy -query \"txid$var_txid\[Subtree\]\" | efetch -format xml | xtract -pattern Taxon -tab \"\t\" -element TaxId -element ScientificName -block LineageEx/Taxon -if Rank -equals genus -element ScientificName -block LineageEx/Taxon -if Rank -equals family -element ScientificName -block LineageEx/Taxon -if Rank -equals order -element ScientificName -block LineageEx/Taxon -if Rank -equals class -element ScientificName >> NCBI_taxonomy_summary.tsv");
}


print  localtime() . " Done Downloading NCBI Taxonomic Table\n";
print  $log localtime() . " Done Downloading NCBI Taxonomic Table\n";

open my $fh_filtered, './NCBI_taxonomy_summary.tsv' or die "Cannot open NCBI_taxonomy_summary.tsv\n";
my %info;


while (my $line = <$fh_filtered>) {
    chomp $line;
    my @fields = split(/\t/, $line);

    my ($spp_id, $genus_id, $family_id, $order_id, $class_id) = @fields[1, 2, 3, 4, 5];

    
    if (defined $spp_id && $spp_id ne '') {
        $info{$spp_id} = {
            genus  => $genus_id,
            family => $family_id,
            order  => $order_id,
            class  => $class_id,
        };
    } else {
       
    }
}

close $fh_filtered;


my $fasta_dir = './';


my %species_table;
my @files;


opendir(my $dir, $fasta_dir) or die "Could not open $fasta_dir\n";
@files = grep { /\.fasta$/ } readdir($dir);
closedir($dir);


foreach my $file (@files) {
    my $file_path = "$fasta_dir/$file";
    open my $fh, '<', $file_path or die "Could not open $file_path\n";

 while (my $line = <$fh>) {
    chomp $line;
    if ($line =~ /^>(\w+)_(\w+)(?:_x_(\w+)_(\w+))?_(.*)/) {
        my $genus1 = $1;
        my $species1 = $2;
        my $genus2 = $3;
        my $species2 = $4;
        my $accession = $5;    

        my $species_str;
        if (defined $genus2 && defined $species2) {
            $species_str = "$genus1\_$species1\_x\_$genus2\_$species2";
        } else {
            $species_str = "$genus1\_$species1";
        }

        $species_str =~ s/_/ /g;

        
        push @{$species_table{$species_str}{$file}}, $accession;

        
        foreach my $spp_id (keys %info) {
            if ($genus1 eq $info{$spp_id}{genus}) {
                $species_table{$species_str}{taxonomy} = $info{$spp_id};
            }
        }
    }
}



open my $fh, '>', 'Species_data.csv' or die "Could not open file Species_data.csv ";


my @file_names;
foreach my $species (keys %species_table) {
    foreach my $file (keys %{$species_table{$species}}) {
        next if $file eq 'taxonomy';  
        (my $file_name = $file) =~ s/\.fasta$//;  
        push @file_names, $file_name unless grep { $_ eq $file_name } @file_names;  
    }
}


print $fh "Class,Order,Family,Genus,Species," . join(",", @file_names) . "\n";


foreach my $species (sort keys %species_table) {
    my $taxonomy = $species_table{$species}{taxonomy} || {};

    
    my $class = $taxonomy->{class} // 'NA';
    my $order = $taxonomy->{order} // 'NA';
    my $family = $taxonomy->{family} // 'NA';
    my $genus = $taxonomy->{genus} // 'NA';

    
    my @accessions_row;

    
    foreach my $file (@file_names) {
    my $accessions = join('; ', @{$species_table{$species}{"$file.fasta"}}) if exists $species_table{$species}{"$file.fasta"};
          push @accessions_row, ($accessions // 'NA');  
    }

    
    print $fh join(",", $class, $order, $family, $genus,$species, @accessions_row) . "\n";
}


close $fh;

}
}
else {
print  localtime() . " Using a local taxonomic table.\n";
print  $log localtime() . " Using a local taxonomic table.\n";

open my $fh_filtered, './ALL_taxonomy_summary.tsv' or die "Cannot open ./ALL_taxonomy_summary.tsv\n";
my %info;


while (my $line = <$fh_filtered>) {
    chomp $line;
    my @fields = split(/\t/, $line);

        my ($spp_id, $genus_id, $family_id, $order_id, $class_id) = @fields[4,3,2,1,0];  

    
    if (defined $spp_id && $spp_id ne '') {
        $info{$spp_id} = {
            genus  => $genus_id,
            family => $family_id,
            order  => $order_id,
            class  => $class_id,
        };
    } else {
       
    }
}

close $fh_filtered;


my $fasta_dir = './';


my %species_table;
my @files;


opendir(my $dir, $fasta_dir) or die "Could not open $fasta_dir\n";
@files = grep { /\.fasta$/ } readdir($dir);
closedir($dir);


foreach my $file (@files) {
    my $file_path = "$fasta_dir/$file";
    open my $fh, '<', $file_path or die "Could not open $file_path\n";

 while (my $line = <$fh>) {
    chomp $line;
    if ($line =~ /^>(\w+)_(\w+)(?:_x_(\w+)_(\w+))?_(.*)/) {
        my $genus1 = $1;
        my $species1 = $2;
        my $genus2 = $3;
        my $species2 = $4;
        my $accession = $5;    

        my $species_str;
        if (defined $genus2 && defined $species2) {
            $species_str = "$genus1\_$species1\_x\_$genus2\_$species2";
        } else {
            $species_str = "$genus1\_$species1";
        }

        $species_str =~ s/_/ /g;

        
        push @{$species_table{$species_str}{$file}}, $accession;

        
        foreach my $spp_id (keys %info) {
            if ($genus1 eq $info{$spp_id}{genus}) {
                $species_table{$species_str}{taxonomy} = $info{$spp_id};
            }
        }
    }
}



open my $fh, '>', 'Species_data.csv' or die "Could not open file Species_data.csv ";
my @file_names;
foreach my $species (keys %species_table) {
    foreach my $file (keys %{$species_table{$species}}) {
        next if $file eq 'taxonomy';  
        (my $file_name = $file) =~ s/\.fasta$//;  
        push @file_names, $file_name unless grep { $_ eq $file_name } @file_names;  
    }
}


print $fh "Class,Order,Family,Genus,Species," . join(",", @file_names) . "\n";


foreach my $species (sort keys %species_table) {
    my $taxonomy = $species_table{$species}{taxonomy} || {};

    
    my $class = $taxonomy->{class} // 'NA';
    my $order = $taxonomy->{order} // 'NA';
    my $family = $taxonomy->{family} // 'NA';
    my $genus = $taxonomy->{genus} // 'NA';

    
    my @accessions_row;

    
    foreach my $file (@file_names) {
    my $accessions = join('; ', @{$species_table{$species}{"$file.fasta"}}) if exists $species_table{$species}{"$file.fasta"};
          push @accessions_row, ($accessions // 'NA');  
    }
    print $fh join(",", $class, $order, $family, $genus,$species,@accessions_row) . "\n";
}


close $fh;

}

}
print localtime() . " Successfully generated summary of the sequences and taxonomic coverage sampled\n";
print  $log localtime() . " Successfully generated summary of the sequences and taxonomic coverage sampled\n";

}
sub txnmc_clstr_ncbi{
    txnmc_db_only();
    blst_only();
    clstr_only();
    }
sub clstr_only{
use File::Copy;
use List::Util qw(all);
use File::Path qw(make_path);
use IO::Handle;  
use POSIX;


STDOUT->autoflush(1);



print localtime() . " Starting Cluster Phase\n";
print $log localtime() . " Starting Cluster Phase\n";
my $newdir = '0.Filtered_info';
my @final_clstr;
my @excluded;

unless (-d $newdir) {
    eval {
        make_path($newdir);
    };
    if ($@) {
        die "Failed to create directory $newdir\n";
    }
}

open my $cfg, '<', "./D4rwin_cfg.txt" or die "Cannot open D4rwin_cfg.txt\n";
my $mnm_spp=+0;
my $filtering_prmtr=+0;
my $coverage_pcrtg=+0;
my $folder_name;
my $threads_clstrs=+0;
while (my $line = <$cfg>) {
    chomp $line;
    if ($line =~ /Minimum Sequences Per Cluster=(.*);/) {
        $mnm_spp = $1;
        $mnm_spp =~ s/^\s+|\s+$//g;
    }
    if ($line =~ /Filtering Parameter=(\d+);/) {
        $filtering_prmtr = 0 + $1;  
        $filtering_prmtr =~ s/^\s+|\s+$//g;
    }
    if ($line =~ /Minimum Parameter Value=(\d+);/) {
        $coverage_pcrtg =$1;
        $coverage_pcrtg =~ s/^\s+|\s+$//g;
    }
    if ($line =~ /File Name=(.*);/) {
        $folder_name = $1;
        $folder_name =~ s/\s+/_/g;
    }
 if ($line =~ /Threads Available For Clustering=(\d+);/) {
        $threads_clstrs = $1;
    }
}
close $cfg;
my $max_threads=  $threads_clstrs; 


    my $input_file = "$folder_name.ouftl.txt";
    my %counts;

    open my $in_fh, '<', $input_file or die "Cannot open file $input_file\n";

    
    while (my $line = <$in_fh>) {
        chomp $line;
        my @fields = split /\t/, $line;
        my $value = $fields[0];  
        $counts{$value}++;
    }
    close $in_fh;

    

  my %seen_combinations;  
my %stored_results;     

    
    open my $in_fh2, '<', $input_file or die "Cannot open file $input_file\n";
   my $high2="$newdir/High_Txnmc_$folder_name.tsv";
open my $high_out2, '>', $high2 or die "Cannot open log.txt\n";
       my $low2 = "$newdir/Low_Txnmc_$folder_name.tsv";
open my $low_out2, '>>', $low2 or die "Cannot open log.txt\n";
print $low_out2 "Query_id\tSubject_ids\tSequences\tClasses\tOrders\tFamilies\tGenus\tSpecies\tSpecies list\n";
print $high_out2 "Query_id\tSubject_ids\tSequences\tClasses\tOrders\tFamilies\tGenus\tSpecies\tSpecies list\n";
close $low_out2;
close $high_out2;
    

    foreach my $value (keys %counts) {
        if ($counts{$value} >= $mnm_spp) {
            while (my $line2 = <$in_fh2>) {
                chomp $line2;
                my @fields = split(/\t/, $line2);
                
                my $query_id = $fields[0];  
                my $subject_id = $fields[1]; 
                my $parameter;                

                if ($filtering_prmtr eq 3 && defined $fields[3]) {
                    $parameter = $fields[3];
                } elsif ($filtering_prmtr eq 4 && defined $fields[4]) {
                    $parameter = $fields[4];
                } elsif ($filtering_prmtr eq 5 && defined $fields[5]) {
                    $parameter = $fields[5];
                } elsif ($filtering_prmtr eq 6 && defined $fields[6]) {
                    $parameter = $fields[6];
                }

            if (defined $parameter) {
                if ($parameter >= $coverage_pcrtg) {
                    
                    my $unique_key = join(':', sort($query_id, $subject_id));

                    
                    unless (exists $seen_combinations{$unique_key}) {
                        
                        $stored_results{$query_id}{$subject_id} = {
                            percentage => $parameter,
                        };

                        
                        $seen_combinations{$unique_key} = 1;
                                       

                    } else {
                    }
                } else {
                }
            }
        }
    }
}


foreach my $query_id (keys %stored_results) {
    my $subject_count = keys %{ $stored_results{$query_id} };  

    if ($subject_count >= $mnm_spp) {  
        foreach my $subject_id (keys %{ $stored_results{$query_id} }) {
                                   $total_steps = keys %stored_results;  
        }
    }
}



my ($classes2, $orders, $fam, $gen, $spps)=0;
my ($classesper, $ordersper, $famper, $genper, $sppsper)=0;
my $txnmc_ncbi_flag=0;
my $txnmc_name;
my $txnmc_names;
my $auto_flag=0;
open my $cfg, '<', "./D4rwin_cfg.txt" or die "Cannot open D4rwin_cfg.txt\n";

while (my $line = <$cfg>) {
        $auto_flag = 1 if $line =~ /Delimit All Values For Each Taxonomic Coverage=Auto;/;
   $txnmc_ncbi_flag = 1 if $line =~ /Use NCBI Taxonomic Table=Yes;/;
      $txnmc_name= $1 if $line =~ /Taxonomic Identification of Interest \(Txids\)=([\d+;]+)/;
}
close $cfg;
     open my $cfg, '<', "./D4rwin_cfg.txt" or die "Cannot open D4rwin_cfg.txt\n";
   while (my $line = <$cfg>) {

	if ($auto_flag eq 0){
    $classes2 = $1 if $line =~ /Minimum Classes Per Cluster=(\d+);/;
    $orders   = $1 if $line =~ /Minimum Orders Per Cluster=(\d+);/;
    $fam      = $1 if $line =~ /Minimum Families Per Cluster=(\d+);/;
    $gen      = $1 if $line =~ /Minimum Genus Per Cluster=(\d+);/;
    $spps     = $1 if $line =~ /Minimum Species Per Cluster=(\d+);/;
}
     if ($auto_flag eq 1){
     
   $classesper = $1 if $line =~ /Minimum Classes Per Cluster=(0\.\d+);/;
    $ordersper   = $1 if $line =~ /Minimum Orders Per Cluster=(0\.\d+);/;
    $famper      = $1 if $line =~ /Minimum Families Per Cluster=(0\.\d+);/;
    $genper      = $1 if $line =~ /Minimum Genus Per Cluster=(0\.\d+);/;
    $sppsper     = $1 if $line =~ /Minimum Species Per Cluster=(0\.\d+);/;
}}
close $cfg;
close $in_fh;
my @txnmc_names = split(/;/, $txnmc_name);

my $cluster_dir = '0.Clusters';

unless (-d $cluster_dir) {
    
    eval {
        make_path($cluster_dir);
    };
    if ($@) {
        die "Failed to create directory $cluster_dir\n";
    }
} else {

}
my %info;

if ($txnmc_ncbi_flag == 1) {
 print  localtime() . " Downloading NCBI taxonomic table.\n";
print  $log localtime() . " Downloading NCBI taxonomic table.\n";
my $ncbifile = "./NCBI_taxonomy_summary.tsv";  

if (-e $ncbifile) {
    unlink($ncbifile);
}
open my $fh_filtered, '>', './NCBI_taxonomy_summary.tsv' or die "Cannot open NCBI_taxonomy_summary.tsv: $!\n";
print $fh_filtered "TxId\tScientific Name\tGenus\tFamily\tOrder\tClass\n";
close $fh_filtered;
foreach my $var_txid (@txnmc_names) {
    system("esearch -db taxonomy -query \"txid$var_txid\[Subtree\]\" | efetch -format xml | xtract -pattern Taxon -tab \"\t\" -element TaxId -element ScientificName -block LineageEx/Taxon -if Rank -equals genus -element ScientificName -block LineageEx/Taxon -if Rank -equals family -element ScientificName -block LineageEx/Taxon -if Rank -equals order -element ScientificName -block LineageEx/Taxon -if Rank -equals class -element ScientificName >> NCBI_taxonomy_summary.tsv");
}

print  localtime() . " Done NCBI taxonomic table.\n";
print $log localtime() . " Done NCBI taxonomic table.\n";

    open my $fh_filtered, './NCBI_taxonomy_summary.tsv' or die "Cannot open ./NCBI_taxonomy_summary.tsv: $!";

    while (my $line = <$fh_filtered>) {
        chomp $line;
        my @fields = split(/\t/, $line);
        
        
        my ($spp_id, $genus_id, $family_id, $order_id, $class_id) = @fields[1, 2, 3, 4, 5];  
        
        $info{$spp_id} = {
            genus  => $genus_id,
            family => $family_id,
            order  => $order_id,
            class  => $class_id,
        };
    }
    close $fh_filtered;
}
if ($txnmc_ncbi_flag == 0) {
    open my $fh_filtered, './ALL_taxonomy_summary.tsv' or die "Cannot open ./ALL_taxonomy_summary.tsv: $!";

    while (my $line = <$fh_filtered>) {
        chomp $line;
        my @fields = split(/\t/, $line);
        
        
        my ($spp_id, $genus_id, $family_id, $order_id, $class_id) = @fields[4,3,2,1,0];  

        
        $info{$spp_id} = {
            genus  => $genus_id,
            family => $family_id,
            order  => $order_id,
            class  => $class_id,
        };
    }
    close $fh_filtered;
}
my %unique_classes;
my %unique_orders;
my %unique_families;
my %unique_genera;
my %unique_species;
my $classes_value;
my $orders_value;
my $family_value;
my $genera_value;
my $species_value;

if ($auto_flag == 1){
foreach my $spp_id (keys %info) {
    my $genus  = $info{$spp_id}->{genus};
    my $family = $info{$spp_id}->{family};
    my $order  = $info{$spp_id}->{order};
    my $class  = $info{$spp_id}->{class};
    
    $unique_genera{$genus}++;
    $unique_families{$family}++;
    $unique_orders{$order}++;
    $unique_classes{$class}++;
    $unique_species{$spp_id}++;
}
$classes_value=scalar(keys %unique_classes)-1;
$orders_value=scalar(keys %unique_orders)-1;
$family_value=scalar(keys %unique_families)-1;
$genera_value=scalar(keys %unique_genera)-1;
$species_value=scalar(keys %unique_species)-1;

$classes2 = ceil($classes_value*$classesper);
$orders = ceil($orders_value*$ordersper);
$fam = ceil($family_value*$famper);
$gen = ceil($genera_value*$genper);
$spps = ceil($species_value*$sppsper);


}

print  localtime() . " Filtering per taxonomic coverage\n";
print  localtime() . " Parameters:Classes>=$classes2|Orders>=$orders|Families>=$fam|Genus>=$gen|Species>=$spps\n";
print  $log localtime() . " Filtering per taxonomic coverage\n";
print  $log localtime() . " Parameters:Classes>=$classes2|Orders>=$orders|Families>=$fam|Genus>=$gen|Species>=$spps\n";

my %file_spp;
my $species;



my %query_results;
use threads;
use threads::shared;



my $counter : shared = 0;
        open(my $fh_fasta, '<', "./$folder_name.fasta") or die "Can't open file: $!";

sub process_query {
    my ($query_id) = @_;
                {
                lock($counter);
$counter++;
}

my %file_spp;
my $species;

    my %family_found;   
    my $family_count = 0; 
    my $order_count = 0; 
    my %order_found; 
    my %genus_found;   
    my $genus_count = 0; 
    my %classes_found;   
    my $classes_count = 0; 
    my $species_count = 0; 
    my $subject_ids;
    my %matched_sequences;
    my @subj;

    my $subject_count = keys %{ $stored_results{$query_id} };  

    if ($subject_count >= $mnm_spp) {  
        my $subject_ids = join(',', keys %{ $stored_results{$query_id} }); 
        push @subj, keys %{ $stored_results{$query_id} }; 

        
        open(my $fh_fasta, '<', "./$folder_name.fasta") or die "Can't open file ./$folder_name.fasta";
        
        while (my $line = <$fh_fasta>) {
            foreach my $subject_id (keys %{ $stored_results{$query_id} }) {
                if ($line =~ /^>$subject_id\s+(\w+).*/) { 
                    my ($genus) = ($1);    
if ($line =~ /^>$subject_id (\w+) (\w+)(?: x (\w+) (\w+))?.*/) {
    my $genus1 = $1;
    my $species1 = $2;
    my $genus2 = $3;
    my $species2 = $4;

    
    my $species = defined $genus2 && defined $species2
        ? "$genus1 $species1 x $genus2 $species2"
        : "$genus1 $species1";

    
    if (!exists $file_spp{$query_id}{$species}) {
        $file_spp{$query_id}{$species} = $species; 
        
    }
}




   
                    foreach my $spp_id (keys %info) {

                        if ($info{$spp_id}{genus} eq $genus) {
                            my $order = $info{$spp_id}{order};
                            my $family = $info{$spp_id}{family};
                            my $classes = $info{$spp_id}{class};				
                            
                            if (!$order_found{$order}++) {
                                $order_count++;
                            }
                            if (!$genus_found{$genus}++) {
                                $genus_count++;
                            }
                            if (!$family_found{$family}++) {
                                $family_count++;
                            }
                            if (!$classes_found{$classes}++) {
                                $classes_count++;
                            }
                        }
                    }
                }
            }
        }
                close($fh_fasta);

        
my @species = keys %{ $file_spp{$query_id} };


$species_count = scalar(@species);


my $species_list = join(", ", @species);


        my $sequence_count = scalar(@subj);
        my $output_file;

        if ($classes_count >= $classes2 && $order_count >= $orders &&
            $family_count >= $fam && $genus_count >= $gen && 
            $species_count >= $spps) {
             open my $tb2, '>>', "0.Filtered_info/output_filtered.txt" or die "Unable to open or create output_filtered.txt because the required parameters were not met for any sequences\n";
        foreach my $var (@subj) {
            print $tb2 $query_id."\t$var\n";
        }
        close $tb2;
            my $output_file = "0.Filtered_info/High_Txnmc_$folder_name.tsv";
                          open my $output_out, '>>', $output_file or die "Cannot open $output_file\n";
        print $output_out "$query_id\t$subject_ids\t$sequence_count\t$classes_count\t$order_count\t$family_count\t$genus_count\t$species_count\t$species_list\n";
        close $output_out;

        } elsif($classes_count < $classes2 || $order_count < $orders ||
            $family_count < $fam || $genus_count < $gen ||
            $species_count < $spp) {
           my $output_file2 = "0.Filtered_info/Low_Txnmc_$folder_name.tsv";
             open my $output_out2, '>>', $output_file2 or die "Cannot open $output_file\n";
        print $output_out2 "$query_id\t$subject_ids\t$sequence_count\t$classes_count\t$order_count\t$family_count\t$genus_count\t$species_count\t$species_list\n";
        close $output_out2;
        }


        
        my $bar_length = 50;  
        my $filled_length = int(($counter / $total_steps) * $bar_length);  
        my $bar = '#' x $filled_length . '-' x ($bar_length - $filled_length);  
        my $percent = int(($counter / $total_steps) * 100);
        
       {
    lock($counter);
    if ($counter <= $total_steps) {
        print "\r[$bar] $counter/$total_steps \($percent%\) clusters";
    }
}

    }
        close($fh_fasta);

}
my @threads;


foreach my $query_id (keys %stored_results) {
  while (scalar(threads->list(threads::running)) >= $max_threads) {
        
        foreach my $thr (@threads) {
            if ($thr->is_joinable()) {
                $thr->join();  
            }
        }
        
        sleep(1);
    }

    
    push @threads, threads->create(\&process_query, $query_id);
}
foreach my $thr (@threads) {
    if ($thr->is_joinable()) {
        $thr->join();
    } else {
        $thr->join() if $thr->is_running();  
    }
}




my %sequences;


open my $fh_filtered, '<', "0.Filtered_info/output_filtered.txt" or die "Cannot open output_filtered.txt\n";


my %query_subject_pairs;

while (my $line = <$fh_filtered>) {
    chomp $line;
    my @fields2 = split(/\t/, $line);
    my ($query_id2, $subject_id2) = @fields2[0, 1];

    
    push @{ $query_subject_pairs{$query_id2} }, $subject_id2;
}


open my $fh_fasta, '<', $folder_name.".fasta" or die "Cannot open $folder_name.fasta\n";


my $header = '';
my $sequence = '';

while (my $line_fasta = <$fh_fasta>) {
    chomp $line_fasta;
my $flag=0;
    if ($line_fasta =~ /^>(.*)/) {  
        if ($header) {
            
            foreach my $query_id (keys %query_subject_pairs) {
                if (grep { $header =~ /^$_/ } @{ $query_subject_pairs{$query_id} }) {
                    
                    push @{ $sequences{$query_id} }, { header => $header, sequence => $sequence };
                }
            }
        }
        $header = $1;  
        $sequence = '';  
    } else {
        $sequence .= $line_fasta;  
    }
}

if ($header) {
    foreach my $query_id (keys %query_subject_pairs) {
        if (grep { $header =~ /^$_/ } @{ $query_subject_pairs{$query_id} }) {
            
            push @{ $sequences{$query_id} }, { header => $header, sequence => $sequence };
        }
    }
}

close $fh_fasta;
print "\n".localtime() . " Done filtering per taxonomic coverage\n";
print  $log "\n".localtime() . " Done filtering per taxonomic coverage\n";
print localtime() . " Generating clusters of sequences\n";
print $log localtime() . " Generating clusters of sequences\n";

my $unique_entries : shared;
my $counter2 : shared=0;
my @threads2;  


foreach my $query_id (keys %sequences) {
    while (scalar(threads->list(threads::running)) >= $max_threads) {
        foreach my $thr2 (@threads2) {
            if ($thr2->is_joinable()) {
                $thr2->join();  
            }
        }
        sleep(1);
    }

    
    push @threads2, threads->create(sub {
        my $local_query_id = $query_id;
        open my $fh_out, '>', "0.Clusters/${local_query_id}.fasta" or die "Cannot open ${local_query_id}.fasta\n";

        {
            lock($counter2);
            $counter2++;
        }

        my %seen_entries;
        foreach my $entry (@{ $sequences{$local_query_id} }) {
            next if $seen_entries{$entry->{header}}++;

            if (defined $entry->{header} && defined $entry->{sequence}) {
                print $fh_out ">$entry->{header}\n$entry->{sequence}\n";
            } else {
                warn "Missing header or sequence for $local_query_id\n";
            }
        }
        close $fh_out;
    my $total_steps2 = keys %sequences;
my $bar_length2 = 50;  
my $filled_length2 = int(($counter2 / $total_steps2) * $bar_length2);  
my $bar2 = '#' x $filled_length2 . '-' x ($bar_length2 - $filled_length2);  
my $percent2 = int(($counter2 / $total_steps2) * 100);
 {
    lock($counter2);
    if ($counter2 <= $total_steps2) {
        print "\r[$bar2] $counter2/$total_steps2 \($percent2%\) clusters";
    }
}

});


}
foreach my $thr2 (@threads2) {
    if ($thr2->is_joinable()) {
        $thr2->join();
    } else {
        $thr2->join() if $thr2->is_running();  
    }
}
print "\n".localtime() . " Done generating clusters of sequences\n";
print $log "\n". localtime() . " Done generating clusters of sequences\n";
print localtime() . " Generating table containing clusters deflines\n";
print $log localtime() . " Generating table containing clusters deflines\n";
my $source_dir ="./0.Clusters/"; 

opendir(my $dh, $source_dir) or die "Cannot open directory $source_dir\n";


my @files = map { s/\.fasta$//r } grep { /\.fasta$/ && -f "$source_dir/$_" } readdir($dh);
foreach my $file (@files) {
    
    open my $fh, '<', "$source_dir/$file.fasta" or die "Cannot open file $file\n";
    
    open my $fh_out, '>', "$source_dir/$file.xls" or die "Cannot open file $file.xls\n";
    
    while (my $line = <$fh>) {
        chomp($line);
        if ($line =~ /^>(.*)/) {
            my $def = $1;
            $def =~ s/[;,]/ /g;
            print $fh_out "$def\n";
        }
    }
    
    
    close $fh;
    close $fh_out;

}

my $xls_dir ="./0.Clusters/"; 
my $output_file ="./0.Clusters/".'Table_Clusters.csv';


open my $fh_out, '>', $output_file or die "Cannot open $output_file\n";


my @xls_files = glob("$xls_dir/*.xls");


my @columns;
my $clst_count=0;
my $clstr;
my @clstrs;

foreach my $file (@xls_files) {
    
    open my $fh_in, '<', $file or die "Cannot open file $file\n";
      $clst_count++;       
$clstr = $clst_count; 
push @clstrs, $clstr; 

    
    my @column_data = <$fh_in>;
    chomp @column_data;
    
    
    close $fh_in;

    
    push @columns, \@column_data;
}
@clstrs = sort { $a <=> $b } @clstrs;


my $max_rows = 0;

foreach my $col (@columns) {
    $max_rows = @$col if @$col > $max_rows;

}




my @headers = map { "Cluster " . ($_ + 1) } (0 .. $#columns);
print $fh_out join(',', @headers) . "\n";


for my $row (0 .. $max_rows - 1) {
    my @line;
    
    
    foreach my $col (@columns) {
        push @line, defined $col->[$row] ? $col->[$row] : '';
    }

    
    print $fh_out join(',', @line) . "\n";
}

close $fh_out;  




unlink glob("$source_dir/*.xls");
unlink "0.Filtered_info/output_filtered.txt";
print localtime() . " Successfully generated table containing clusters deflines\n";
print $log localtime() . " Successfully generated table containing clusters deflines\n";

print $log localtime() . " Formatting sequences to the format >Genus_species_accessionNumber\n";
print localtime() . " Formatting sequences to the format >Genus_species_accessionNumber\n";


my $directory = './0.Clusters/';


opendir(my $dh, $directory) or die "Can't open directory\n";


my @refo_clsts = grep { /\.fasta$/ && -f "$directory/$_" } readdir($dh);
closedir($dh);

foreach my $newfor (@refo_clsts) {
    my $input_file = "$directory/$newfor";
    my $output_file = "$directory/$newfor\_";

    open my $input_fh, '<', $input_file or die "Can't open input file: $input_file\n";
    open my $output_fh, '>', $output_file or die "Can't open output file: $output_file\n";

    
    while (my $line = <$input_fh>) {
        chomp $line;
$line =~ s/^>(\w+)_(\w+\.\d+)/>$1$2/;

        
        if ($line =~ /^>(\w+\.\d+)\s+(\w+)\s+(\w+)\s+x\s+(\w+)\s+(\w+)/) {
            my $accession = $1;

            my $spp1 = "$2_$3";  
            my $spp2 = "$4_$5";  

            
            print $output_fh ">$spp1\_x\_$spp2\_$accession\n";
        }

        
        elsif ($line =~ /^>(\w+\.\d+)\s+(\w+)\s+(\w+)/) {
            my $accession = $1;

            my $spp = "$2_$3";   

            
            print $output_fh ">$spp\_$accession\n";
        }

        
        else {
            print $output_fh "$line\n";  
        }
    }

    
    rename($output_file, $input_file) or die "Renamed Phase failed\n";

    
    close $input_fh;
    close $output_fh;
}

print $log localtime() . " Successfully formated sequences to the format >Genus_species_accessionNumber\n";
print localtime() . " Successfully formated sequences to the format >Genus_species_accessionNumber\n";


}
sub cnvrt_mrkrs{
use strict;
use File::Copy; 
 print localtime() . " Formatting clusters for the BLAST run stage again\n";
 print $log localtime() . " Formatting clusters for the BLAST run stage again\n";
my $nm_file;
my $destination_folder = './0.MarkersAvailableForBLAST';

my $folder = "./"; 
my @files = glob("$folder/*.fasta");
mkdir $destination_folder unless -d $destination_folder;
my $destination_file;

foreach my $file (@files) {
    $file =~ s/\.fasta$//;

    my $input_file  = "$file.fasta";     
    my $output_file = "${file}_old.fasta";  

    open(my $in_fh, '<', $input_file) or die "Cannot open $input_file: $!";

    open(my $out_fh, '>', $output_file) or die "Cannot open $output_file: $!";
$nm_file=$file;
    $nm_file =~ s/\.\/\///;

    while (my $line = <$in_fh>) {
        chomp($line);  
        
        if ($line =~ />(.*)/) {
            $line =~ s/_/ /g;  
            print $out_fh "$line $nm_file\n";  
        } else {
            print $out_fh "$line\n";
        }
    }
    close($in_fh);
    close($out_fh);

    open(my $in_fh2, '<', $output_file) or die "Cannot open $output_file: $!";
    
    my $final_output_file = "${file}_available.fasta";
    my $source_file = './'."${file}_available.fasta";        
    my $destination_file = "$destination_folder/${file}_available.fasta";

    open(my $final_out_fh, '>', $final_output_file) or die "Cannot open $final_output_file: $!";

    while (my $line = <$in_fh2>) {
        chomp($line);  
                if ($line =~ />(.+?) (\w+\.\d+)/) {
            $line = ">$2 $1"; 
        }    
        print $final_out_fh "$line\n";
    
    }

    close($in_fh2);
    unlink $output_file;
    close($final_out_fh);
move($source_file, $destination_file) or die "Cannot copy $source_file to $destination_file: $!";
}
print localtime() . " Successfully formatted Clusters for the BLAST run stage again.\n";
print $log localtime() . " Successfully formatted Clusters for the BLAST run stage again.\n";
}
}
close $log;
