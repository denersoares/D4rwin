import os
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk  # Import ttk for style customization

def print_in_square(text):
    """Function to print text inside a square box (for formatting)."""
    print(f"+{'-' * (len(text) + 2)}+")
    print(f"| {text} |")
    print(f"+{'-' * (len(text) + 2)}+")

def get_perl_script_path():
    """Function to get the Perl script path from the same directory as the Python script."""
    python_dir = os.path.dirname(os.path.realpath(__file__))  # Get directory of this Python script
    perl_script = os.path.join(python_dir, ".perlscript/D4rwin.pl")  # Append the Perl script filename
    return perl_script

def show_welcome_message():
    """Show the welcome message in the GUI."""
    # Correct definition for commands_info
    commands_info = [
        ("1) Assembling Taxonomic Database", "txnmc_db_only\n\n"),
        ("2) BLAST stage", "blst_only\n\n"),
        ("3) Clustering Sequences", "clstr_only\n\n"),
        ("4) Formatting Sequences to the format >species_accession_number", "reformat\n\n"),
        ("5) Assembling Taxonomic Database Available in NCBI, BLAST and Clustering Sequences", "txnmc_clstr_ncbi\n\n"),
        ("6) BLAST Local Database and Clustering Sequences", "txnmc_clstr_local\n\n"),
        ("7) Renaming Sequences", "rnm_clstr\n\n"),
        ("8) Filtering Per Taxonomic level", "filtr_per_txnmc_lvl\n\n"),
        ("9) Generating a Summary of Markers", "summry_markers\n\n"),
        ("10) Converting Sequences to Rerun BLAST", "cnvrt_mrkrs\n\n"),
        ("11) Learning about the commands", "help\n\n"),
        ("Read ReadMe.txt file for detailed information about D4rwin V.1.", "")
    ]
    
    # Max width for the Text widget (set to 80)
    max_line_length = 80
    centered_message = ""

    # Add the welcome message with centered text
    welcome_message = "            Welcome to D4rwin V.1!\n\nPlease provide one of the following commands for:\n\n"

    # Center the welcome message
    centered_message += " " * ((max_line_length - len(welcome_message.strip())) // 2) + welcome_message

    # Add the commands info, aligned to the left
    for title, command in commands_info:
        centered_message += f"{title}\n{command}"

    # Insert the centered message into the Text widget
    text_widget.config(state=tk.NORMAL)  # Enable editing so we can insert text

    # Insert the entire centered message
    text_widget.insert(tk.END, centered_message)

    # Apply bold formatting to the welcome message title (centered)
    text_widget.tag_configure("bold", font=("Arial", 12, "bold"))
    
    # Apply the bold tag to the welcome message
    start_index = "1.0"  # Start from the beginning of the text widget
    end_index = f"1.{len(welcome_message.strip())}"  # End at the end of the welcome message
    text_widget.tag_add("bold", start_index, end_index)

    text_widget.config(state=tk.DISABLED)  # Disable editing after inserting text

def change_directory():
    """Function to change the working directory."""
    new_dir = filedialog.askdirectory()  # Open a dialog for the user to select a directory
    if new_dir:
        os.chdir(new_dir)  # Change to the selected directory
        label_directory.config(text=f"Current directory: {new_dir}")  # Update the label to show the new directory
def execute_perl_script():
    """Function to execute the Perl script with the given arguments."""
    perl_script = get_perl_script_path()  # Get the path to the Perl script
    arg0 = combo_command.get()
    arg1 = entry_config_file.get()
    
    if not arg0 or not arg1:
        messagebox.showerror("Error", "Please provide all inputs!")
        return
    
    command = f"perl {perl_script} {arg0} {arg1}"
    
    try:
        subprocess.run(command, shell=True, check=True)
        # Ask if the user wants to run another command
        result = messagebox.askquestion("Run Another Command?", "Analysis executed successfully! Would you like to enter another command?", icon='question')

        if result == 'yes':
            pass  # Keep the form for editing
        else:
            # Quit the Tkinter loop and kill the terminal process
            root.quit()  # Stop the Tkinter main loop
            
            # Get the terminal process ID
            ppid = os.getppid()  # Get the parent process ID of the script (the terminal)
            
            # Kill the terminal process
            subprocess.run(["kill", "-9", str(ppid)], check=True)
            
            os._exit(0)  # Exit Python script forcefully

    except subprocess.CalledProcessError:
        messagebox.showerror("Error", f"Failed to execute : {command}")

def update_config_file():
    """Function to browse for and set the configuration file."""
    file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])  # Use filedialog here
    entry_config_file.delete(0, tk.END)
    entry_config_file.insert(0, file_path)

# Create the main window (without initial widgets)
root = tk.Tk()
root.title("D4rwin")
root.geometry("800x650")

# Create a style for the scrollbar
style = ttk.Style()
style.configure("TScrollbar",
                gripcount=0,
                thickness=12,
                background="grey",  # Set the color of the scrollbar
                troughcolor="white",  # Set the background of the scrollbar area
                lightcolor="grey",
                darkcolor="white")

# Create a frame to hold the Text widget and Scrollbar
frame_text = tk.Frame(root)
frame_text.pack(pady=10)

# Create a Text widget to display the welcome message with increased size
text_widget = tk.Text(frame_text, height=20, width=80, wrap=tk.WORD, bg="#000000", fg="#00FF00", font=("Arial", 10))
text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Create a Scrollbar and link it to the Text widget
scrollbar = ttk.Scrollbar(frame_text, orient="vertical", command=text_widget.yview, style="TScrollbar")
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Link the scrollbar with the Text widget
text_widget.config(yscrollcommand=scrollbar.set)  # Link scrollbar to the Text widget
text_widget.config(state=tk.DISABLED)  # Make it non-editable

# Define the tag for bold font
text_widget.tag_configure("bold", font=("Arial", 12, "bold"))

# Display the welcome message before the rest of the GUI
show_welcome_message()

# Create a frame to hold the label and button for the directory
frame_directory = tk.Frame(root)
frame_directory.pack(pady=10)

# Create the directory label with bold font
label_directory = tk.Label(frame_directory, text="Current directory: " + os.getcwd(), font=('Arial', 10, "bold"))
label_directory.pack(side=tk.LEFT, padx=5)  # Pack the label to the left

# Create the "Change Directory" button to the right of the label
button_change_dir = tk.Button(frame_directory, text="Change Directory", font=('Arial', 10, "bold"), command=change_directory)
button_change_dir.pack(side=tk.LEFT, padx=5)  # Pack the button to the left (right after the label)

# Initialize form widgets for the command
label_command = tk.Label(root, text="Select Command:", font=('Arial', 10, "bold"))  # Ensure font is not bold
label_command.pack(pady=5)

commands = [
    "txnmc_db_only", "blst_only", "clstr_only", "reformat",
    "txnmc_clstr_ncbi", "txnmc_clstr_local", "rnm_clstr", 
    "filtr_per_txnmc_lvl", "summry_markers", "cnvrt_mrkrs","help"
]

combo_command = tk.StringVar(value=commands[0])
dropdown_commands = tk.OptionMenu(root, combo_command, *commands)
dropdown_commands.pack(pady=5)

# Create a frame to hold the label, entry, and button for "Configuration File"
frame_config = tk.Frame(root)
frame_config.pack(pady=5)

# Create the label with bold font
label_config_file = tk.Label(frame_config, text="Configuration File:", font=('Arial', 10, "bold"))
label_config_file.pack(side=tk.LEFT, padx=5)  # Pack the label to the left

# Create the entry widget for the configuration file
entry_config_file = tk.Entry(frame_config, width=40)
entry_config_file.pack(side=tk.LEFT, padx=5)  # Pack the entry to the left

# Create the "Browse" button to the right of the entry
button_browse_config = tk.Button(frame_config, text="Browse", font=('Arial', 10, "bold"), command=update_config_file)
button_browse_config.pack(side=tk.LEFT, padx=5)  # Pack the button to the left (right after the entry)


button_execute = tk.Button(root, text="Run Analysis",font=('Arial', 10, "bold"), command=execute_perl_script)
button_execute.pack(pady=20)

# Run the main loop
root.mainloop()
