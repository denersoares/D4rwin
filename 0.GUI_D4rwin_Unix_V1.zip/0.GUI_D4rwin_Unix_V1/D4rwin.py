import sys
import subprocess
import threading
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel, QComboBox, QFileDialog, QLineEdit, QDialog, QMessageBox, QTextEdit
from PyQt6.QtCore import QTimer
import os


from pathlib import Path

def get_perl_script_path():
    """Get the Perl script path from the same directory as the Python script."""
    python_dir = Path(__file__).resolve().parent
    perl_script = python_dir / ".perlscript" / "D4rwin.pl"
    return f'"{str(perl_script)}"'  # Ensure the path is quoted properly


def show_welcome_message(text_widget):
    """Show the welcome message in the GUI."""
    commands_info = [
        ("1) Assembling Taxonomic Database", "- txnmc_db_only"),
        ("2) BLAST stage", "- blst_only"),
        ("3) Clustering Sequences", "- clstr_only"),
        ("4) Formatting Sequences", "- reformat"),
        ("5) Taxonomic Database + BLAST + Clustering", "- txnmc_clstr_ncbi"),
        ("6) BLAST Local + Clustering", "- txnmc_clstr_local"),
        ("7) Renaming Sequences", "rnm_clstr"),
        ("8) Filtering Per Taxonomic Level", "- filtr_per_txnmc_lvl"),
        ("9) Summary of Markers", "- summry_markers"),
        ("10) Convert Sequences for BLAST", "- cnvrt_mrkrs"),
        ("11) Help", ""),
        ("Read ReadMe for detailed info on D4rwin V.1.", "")
    ]

    text_widget.setPlainText("Welcome to D4rwin V.1 !\n\nSelect a command below:\n")
    for title, command in commands_info:
        text_widget.append(f"{title} {command}")

def change_directory(label_directory):
    """Function to change the working directory."""
    new_dir = QFileDialog.getExistingDirectory()
    if new_dir:
        os.chdir(new_dir)
        label_directory.setText(f"Current directory: {new_dir}")

def update_config_file(entry_config_file):
    """Browse for and set the configuration file."""
    file_path, _ = QFileDialog.getOpenFileName(filter="Text files (*.txt)")
    entry_config_file.setText(file_path)

def run_script(combo_command, entry_config_file, stop_button, window):
    """Run Perl script in a separate thread to keep GUI responsive."""
    def update_ui_safely(status):
        """Update the UI from the main thread."""
        if status == "Success":
            msg_box("Success", "Analysis completed successfully!")
        else:
            msg_box("Error", "Execution failed!")

    def execute():
        perl_script = get_perl_script_path()
        arg0 = combo_command.currentText()
        arg1 = entry_config_file.text()

        if not arg0 or not arg1:
            QTimer.singleShot(0, lambda: msg_box("Error", "Please provide all inputs!"))
            return

        command = f"perl {perl_script} {arg0} {arg1}"

        try:
            # Start the process and keep a reference to it
            process = subprocess.Popen(command, shell=True)
            window.process = process  # Store the process reference in the window
            stop_button.setEnabled(True)
            process.wait()  # Wait for the process to complete
            stop_button.setEnabled(False)
            QTimer.singleShot(0, lambda: update_ui_safely("Success"))
        except subprocess.CalledProcessError:
            stop_button.setEnabled(False)
            QTimer.singleShot(0, lambda: update_ui_safely("Error"))

    # Run the subprocess in a separate thread
    threading.Thread(target=execute, daemon=True).start()

def stop_analysis(window):
    """Stop the ongoing analysis by terminating the process."""
    if hasattr(window, 'process') and window.process:
        window.process.terminate()
        window.process = None  # Clear the process reference
        window.stop_button.setEnabled(False)
        msg_box("Stopped", "The analysis has been stopped.")
    else:
        msg_box("Error", "No analysis is currently running.")

def msg_box(title, message):
    """Show a message box."""
    msg = QMessageBox()
    msg.setWindowTitle(title)
    msg.setText(message)
    msg.exec()

class D4rwinGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("D4rwin GUI")
        self.setGeometry(100, 100, 800, 650)

        # Main widget and layout
        main_widget = QWidget(self)
        main_layout = QVBoxLayout(main_widget)

        # Text widget for displaying the welcome message
        self.text_widget = QTextEdit(self)
        self.text_widget.setReadOnly(True)
        main_layout.addWidget(self.text_widget)

        # Show welcome message
        show_welcome_message(self.text_widget)

        # Directory selection
        self.label_directory = QLabel(f"Current directory: {os.getcwd()}", self)
        main_layout.addWidget(self.label_directory)

        button_change_dir = QPushButton("Change Directory", self)
        button_change_dir.clicked.connect(lambda: change_directory(self.label_directory))
        main_layout.addWidget(button_change_dir)

        # Command selection
        self.combo_command = QComboBox(self)
        commands = [
            "txnmc_db_only", "blst_only", "clstr_only", "reformat",
            "txnmc_clstr_ncbi", "txnmc_clstr_local", "rnm_clstr", 
            "filtr_per_txnmc_lvl", "summry_markers", "cnvrt_mrkrs", "help"
        ]
        self.combo_command.addItems(commands)
        main_layout.addWidget(self.combo_command)

        # Configuration file selection
        self.entry_config_file = QLineEdit(self)
        button_browse_config = QPushButton("Browse for a Configuration File", self)
        button_browse_config.clicked.connect(lambda: update_config_file(self.entry_config_file))

        config_layout = QVBoxLayout()
        config_layout.addWidget(self.entry_config_file)
        config_layout.addWidget(button_browse_config)
        main_layout.addLayout(config_layout)

        # Execute button
        button_execute = QPushButton("Run Analysis", self)
        button_execute.clicked.connect(lambda: run_script(self.combo_command, self.entry_config_file, self.stop_button, self))
        main_layout.addWidget(button_execute)

        # Stop button
        self.stop_button = QPushButton("Stop Analysis", self)
        self.stop_button.setEnabled(False)  # Disable initially
        self.stop_button.clicked.connect(lambda: stop_analysis(self))
        main_layout.addWidget(self.stop_button)

        # Set the main layout and widget
        self.setCentralWidget(main_widget)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = D4rwinGUI()
    window.show()
    sys.exit(app.exec())
