import tkinter as tk
import os
from tkinter import ttk
from tkinter import messagebox,filedialog

# Set up the main window
root = tk.Tk()
root.title("D4rwin Configuration File Builder")
root.geometry("870x950")

style = ttk.Style()
style.theme_use('default')
root.config(bg="black")

# Set background color for ttk widgets (e.g., buttons, notebook tabs, etc.)
style.configure("TNotebook", background="black")  # Notebook background
style.configure("TNotebook.Tab", background="black", foreground="white")  # Tab background

# Customize the style further for a light, calm look
style.configure("TNotebook.Tab",
                background="black",  # Background color of the tabs
                foreground="white",  # Text color of the tabs
                padding=[10, 5],
                font=("Arial", 14),
                relief="flat")

# Set selected tab styles
style.map("TNotebook.Tab", 
          background=[('selected', 'white'),  # Active tab background (light blue)
                      ('!selected', 'black')],  # Inactive tab background (light gray)
          foreground=[('selected', 'black'),  # Active tab text color (navy blue)
                      ('!selected', 'white')],  # Inactive tab text color (dark gray)
          font=[('selected', ('Arial', 14, 'bold')),  # Bold text for active tab
                ('!selected', ('Arial', 14))])  # Regular text for inactive tabs
def add_tab(notebook, text, bg_color="#2f2f2f"):
    tab = tk.Frame(notebook, bg=bg_color)  # Create a frame for the tab content
    
    # Create a canvas widget inside the tab
    canvas = tk.Canvas(tab)
    
    # Create a vertical scrollbar (use ttk.Scrollbar for styling)
    v_scrollbar = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=v_scrollbar.set)
    
    # Create a horizontal scrollbar (use ttk.Scrollbar for styling)
    h_scrollbar = ttk.Scrollbar(tab, orient="horizontal", command=canvas.xview)
    canvas.configure(xscrollcommand=h_scrollbar.set)
    
    # Change the color of the scrollbar (black background, white slider when active, gray slider when inactive)
    style = ttk.Style()
    style.configure("TScrollbar", 
                    gripcount=0,  # Remove the grip at the end of the scrollbar
                    background="black",  # Scrollbar background color
                    troughcolor="black",  # Background color of the track
                    arrowcolor="white",  # Color of the arrows (if any)
                    sliderlength=30)  # Length of the draggable slider
    
    # Set the active and inactive slider colors
    style.map("TScrollbar",
              background=[("active", "black"), ("!active", "gray")],  # Background color when active and inactive
              slidercolor=[("active", "white"), ("!active", "lightgray")])  # Slider color when active and inactive

    # Apply the style to the scrollbars
    v_scrollbar.config(style="TScrollbar")
    h_scrollbar.config(style="TScrollbar")
    
    # Create a frame inside the canvas that will hold the content
    content_frame = tk.Frame(canvas, bg=bg_color)  # Frame for your content
    
    # Add the content frame to the canvas using create_window
    canvas.create_window((0, 0), window=content_frame, anchor="nw")
    
    # Grid layout for the canvas and scrollbars
    canvas.grid(row=0, column=0, sticky="nsew")  # Makes the canvas expand to fill the tab
    v_scrollbar.grid(row=0, column=1, sticky="ns")  # Vertical scrollbar
    h_scrollbar.grid(row=1, column=0, sticky="ew")  # Horizontal scrollbar
    
    # Update scroll region after adding content
    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))
    
    content_frame.bind("<Configure>", on_frame_configure)
    
    # Ensure that the tab frame expands and fills the available space
    tab.grid_rowconfigure(0, weight=1)  # Ensure row 0 expands
    tab.grid_columnconfigure(0, weight=1)  # Ensure column 0 expands
    
    # Center the content in the content_frame (center horizontally and vertically)
    content_frame.grid_rowconfigure(0, weight=1)  # Row 0 expands vertically
    content_frame.grid_columnconfigure(0, weight=1)  # Column 0 expands horizontally
    
    # Add the canvas to the notebook tab
    notebook.add(tab, text=text)
    
    return content_frame
notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True)

# Create a tab for Core information
core_info_tab = add_tab(notebook, text="Core Information")
# Create File Name field and description
label_file_name = tk.Label(core_info_tab, text="File Name:",font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
label_file_name.pack(pady=2)
desc_file_name = tk.Label(core_info_tab, text="Choose a file name without special characters (?, ;, etc.) or punctuation.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_file_name.pack(pady=2)

entry_file_name = tk.Entry(core_info_tab,bg="#1C1C1C", fg="white")
entry_file_name.pack(pady=2)
# Create Taxonomic Identification field and description
label_txids = tk.Label(core_info_tab, text="Taxonomic Identification of Interest (Txids):",font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
label_txids.pack(pady=2)
entry_txids = tk.Entry(core_info_tab,bg="#1C1C1C", fg="white")
entry_txids.pack(pady=2)
desc_txids = tk.Label(core_info_tab, text="Taxonomic IDs are critical for identifying and downloading taxonomic data from NCBI.\nUse semicolons (;) to separate multiple Taxonomic IDs.\nTaxonomic Identification is available on the GenBank website in the Taxonomy section.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_txids.pack(pady=2)

# Create Use NCBI Taxonomic Table field with Yes/No options
frame_taxonomic = tk.Frame(core_info_tab, bg="#1C1C1C")
frame_taxonomic.pack(pady=2)
label_ncbi_tax_table = tk.Label(frame_taxonomic, text="Use NCBI Taxonomic Table:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_ncbi_tax_table.pack(side=tk.LEFT, padx=5)

var_ncbi_tax_table = tk.StringVar(value="Yes")

radio_yes = tk.Radiobutton(frame_taxonomic, text="Yes", variable=var_ncbi_tax_table, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_taxonomic, text="No", variable=var_ncbi_tax_table, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)

radio_no.pack(pady=2)
desc_ncbi_tax_table = tk.Label(core_info_tab, text="'Yes' uses the NCBI taxonomic table for filtering.\n'No' allows you to provide a custom taxonomy table that matches the required format (e.g., ALL_taxonomy_summary.tsv).", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_ncbi_tax_table.pack(pady=2)

#####
# Create a tab for Taxonomic Stage
taxonomic_info_tab = add_tab(notebook, text="Assembling Taxonomic Database Phase")
# Create NcbiType
label_ncbi_type= tk.Label(taxonomic_info_tab, text="NCBI Database Type:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_ncbi_type.pack(pady=2)
entry_ncbi_type = tk.Entry(taxonomic_info_tab,bg="#1C1C1C", fg="white")
entry_ncbi_type.pack(pady=2)
desc_ncbi_type = tk.Label(taxonomic_info_tab, text="Define the NCBI database to query (eg. nucleotide, protein, etc).", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_ncbi_type.pack(pady=2)
#Targeted
# Create the label and radiobuttons to align horizontally
# Create a Frame to hold the label and radio buttons together
frame_targeted = tk.Frame(taxonomic_info_tab)
frame_targeted.pack(pady=2)

# Create the label and radio buttons inside the frame
label_targeted = tk.Label(frame_targeted, text="Targeted Search:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_targeted.pack(side=tk.LEFT, padx=5)

var_targeted = tk.StringVar(value="No")

radio_yes = tk.Radiobutton(frame_targeted, text="Yes", variable=var_targeted, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_targeted, text="No", variable=var_targeted, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)

# Entry field for targeted search
entry_targeted = tk.Entry(taxonomic_info_tab,bg="#1C1C1C", fg="white")
entry_targeted.pack(pady=2)

# Description label on the next line
desc_targeted = tk.Label(taxonomic_info_tab, 
                         text="'Yes' allows you to specify search terms for focused retrieval (eg. TxIds AND search).\n"
                              "'No' skips Targeted Searching.\n"
                              "Include terms without special characters or punctuation.\n"
                              "Use underscores (_) to merge multiple words and spaces for others.", 
                         font=("Arial", 12), bg="#1C1C1C", fg="white", anchor="w")  # 'anchor="w"' aligns the text to the left
desc_targeted.pack(pady=2, padx=10)

#Flexible
# Create the label and radiobuttons to align horizontally
# Create a Frame to hold the label and radio buttons together
frame_flex = tk.Frame(taxonomic_info_tab)
frame_flex.pack(pady=2)

# Create the label and radio buttons inside the frame
label_flex = tk.Label(frame_flex, text="Flexible Search:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_flex.pack(side=tk.LEFT, padx=5)

var_flex = tk.StringVar(value="No")

radio_yes = tk.Radiobutton(frame_flex, text="Yes", variable=var_flex, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_flex, text="No", variable=var_flex, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)

# Entry field for flex search
entry_flex = tk.Entry(taxonomic_info_tab)
entry_flex.pack(pady=2)

# Description label on the next line
desc_flex = tk.Label(taxonomic_info_tab, 
                         text="'Yes' includes flexible search terms to capture more variable data (eg. TxIds AND(search1 OR search2).\n"
                              "Include terms without special characters or punctuation.\n"
                              "Use underscores (_) to merge multiple words and spaces for others.", 
                         font=("Arial", 12), bg="#1C1C1C", fg="white", anchor="w")  # 'anchor="w"' aligns the text to the left
desc_flex.pack(pady=2, padx=10)
#Exclude
# Create the label and radiobuttons to align horizontally
# Create a Frame to hold the label and radio buttons together
frame_excl = tk.Frame(taxonomic_info_tab)
frame_excl.pack(pady=2)

# Create the label and radio buttons inside the frame
label_excl = tk.Label(frame_excl, text="Exclude Terms Search:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_excl.pack(side=tk.LEFT, padx=5)

var_excl = tk.StringVar(value="No")

radio_yes = tk.Radiobutton(frame_excl, text="Yes", variable=var_excl, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_excl, text="No", variable=var_excl, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)

# Entry field for excl search
entry_excl = tk.Entry(taxonomic_info_tab,bg="#1C1C1C", fg="white")
entry_excl.pack(pady=2)

# Description label on the next line
desc_excl = tk.Label(taxonomic_info_tab, 
                         text="'Yes' excludes sequences containing the specified terms.\n"
                              "Include terms without special characters or punctuation.\n"
                              "Use underscores (_) to merge multiple words and spaces for others.", 
                         font=("Arial", 12), bg="#1C1C1C", fg="white", anchor="w")  # 'anchor="w"' aligns the text to the left
desc_excl.pack(pady=2, padx=10)
#Exclude_Txids
frame_excl_txid = tk.Frame(taxonomic_info_tab)
frame_excl_txid.pack(pady=2)

# Create the label and radio buttons inside the frame
label_excl_txid = tk.Label(frame_excl_txid, text="Exclude Txids:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_excl_txid.pack(side=tk.LEFT, padx=5)

var_excl_txid = tk.StringVar(value="No")

radio_yes = tk.Radiobutton(frame_excl_txid, text="Yes", variable=var_excl_txid, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_excl_txid, text="No", variable=var_excl_txid, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
entry_excl_txid = tk.Entry(taxonomic_info_tab,bg="#1C1C1C", fg="white")
entry_excl_txid.pack(pady=2)

# Description label on the next line
desc_excl_txid = tk.Label(taxonomic_info_tab, 
                         text="'Yes' excludes specific taxonomic IDs provided by the user.\nUse semicolons (;) to separate multiple Taxonomic IDs.\nTaxonomic Identification is available on the GenBank website in the Taxonomy section.", 
                         font=("Arial", 12), bg="#1C1C1C", fg="white", anchor="w")  # 'anchor="w"' aligns the text to the left
desc_excl_txid.pack(pady=2, padx=10)
#ExcludeRec
frame_excl_rec = tk.Frame(taxonomic_info_tab)
frame_excl_rec.pack(pady=2)

# Create the label and radio buttons inside the frame
label_excl_rec = tk.Label(frame_excl_rec, text="Exclude Records",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_excl_rec.pack(side=tk.LEFT, padx=5)

var_excl_rec = tk.StringVar(value="No")

radio_yes = tk.Radiobutton(frame_excl_rec, text="Yes", variable=var_excl_rec, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_excl_rec, text="No", variable=var_excl_rec, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
entry_excl_rec = tk.Entry(taxonomic_info_tab,bg="#1C1C1C", fg="white")
entry_excl_rec.pack(pady=2)

# Description label on the next line
desc_excl_rec = tk.Label(taxonomic_info_tab, 
                         text="'Yes' excludes specific taxonomic IDs provided by the user.", 
                         font=("Arial", 12), bg="#1C1C1C", fg="white", anchor="w")  # 'anchor="w"' aligns the text to the left
desc_excl_rec.pack(pady=2, padx=10)
#Additionsearch
label_add_term= tk.Label(taxonomic_info_tab, text="Additional NCBI Search Terms:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_add_term.pack(pady=2)
entry_add_term = tk.Entry(taxonomic_info_tab,bg="#1C1C1C", fg="white")
entry_add_term.pack(pady=2)
desc_add_term = tk.Label(taxonomic_info_tab, text="These terms must start with logical operators such as OR, AND, or NOT.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_add_term.pack(pady=2)
#Length
# Label for the description of the length filter
label_length = tk.Label(taxonomic_info_tab, text="Length Filter:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_length.pack(pady=2)

# Frame to hold the minimum and maximum entry fields and their labels
frame_length = tk.Frame(taxonomic_info_tab)
frame_length.pack(pady=2)

# Label and Entry for minimum length
label_min_length = tk.Label(frame_length, text="Min:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_min_length.pack(side=tk.LEFT, padx=5)

entry_min_length = tk.Entry(frame_length, width=10,bg="#1C1C1C", fg="white")  # Width defines the size of the entry box
entry_min_length.pack(side=tk.LEFT, padx=5)

# Label and Entry for maximum length
label_max_length = tk.Label(frame_length, text="Max:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_max_length.pack(side=tk.LEFT, padx=5)

entry_max_length = tk.Entry(frame_length, width=10,bg="#1C1C1C", fg="white")
entry_max_length.pack(side=tk.LEFT, padx=5)

# Description for the length filter
desc_length = tk.Label(taxonomic_info_tab, 
                       text="Define a range for sequence lengths. Enter minimum and maximum values in the boxes above.", 
                       font=("Arial", 12), bg="#1C1C1C", fg="white", anchor="w")
desc_length.pack(pady=2, padx=10)
#Batch
label_batch_sz= tk.Label(taxonomic_info_tab, text="Batch Size:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_batch_sz.pack(pady=2)
entry_batch_sz = tk.Entry(taxonomic_info_tab,bg="#1C1C1C", fg="white")
entry_batch_sz.pack(pady=2)
desc_batch_sz = tk.Label(taxonomic_info_tab, text="Specify the number of sequences processed per batch.\nLarger batch sizes may increase memory usage but reduce processing time.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_batch_sz.pack(pady=2)
#Deleting
frame_batch_dlted = tk.Frame(taxonomic_info_tab)
frame_batch_dlted.pack(pady=2)
label_batch_dlt = tk.Label(frame_batch_dlted, text="Delete NCBI Batches After Assembling Database Phase:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_batch_dlt.pack(side=tk.LEFT, padx=5)

var_batch_dlt = tk.StringVar(value="Yes")

radio_yes = tk.Radiobutton(frame_batch_dlted, text="Yes", variable=var_batch_dlt, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_batch_dlted, text="No", variable=var_batch_dlt, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
radio_no.pack(pady=2)
desc_batch_dlt = tk.Label(taxonomic_info_tab, text="'Yes' deletes temporary NCBI batch files after database assembly.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_batch_dlt.pack(pady=2)
# Create a tab for BLAST information
core_BLAST_tab = add_tab(notebook, text= "BLAST Stage")
#BlastTol
label_blastool = tk.Label(core_BLAST_tab, text="BLAST Tool:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_blastool.pack(pady=2)
desc_blastool = tk.Label(core_BLAST_tab, text="Specify the BLAST tool to use (e.g., blastn for nucleotide BLAST, blastp for protein BLAST).", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_blastool.pack(pady=2)
entry_blastool = tk.Entry(core_BLAST_tab)
entry_blastool.pack(pady=2)
#Evalue
label_evalue = tk.Label(core_BLAST_tab, text="E-value:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_evalue.pack(pady=2)
desc_evalue = tk.Label(core_BLAST_tab, text="Define the minimum acceptable E-value for matches.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_evalue.pack(pady=2)
entry_evalue = tk.Entry(core_BLAST_tab)
entry_evalue.pack(pady=2)
#Query
label_query = tk.Label(core_BLAST_tab, text="Query Coverage:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_query.pack(pady=2)
desc_query = tk.Label(core_BLAST_tab, text="Set the minimum percentage of query coverage required for a valid hit.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_query.pack(pady=2)
entry_query = tk.Entry(core_BLAST_tab)
entry_query.pack(pady=2)
#Threads
label_thread = tk.Label(core_BLAST_tab, text="Threads:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_thread.pack(pady=2)
desc_thread = tk.Label(core_BLAST_tab, text="Define the number of threads for BLAST parallel processing.\nEnsure the number of threads does not exceed the available CPU cores.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_thread.pack(pady=2)
entry_thread = tk.Entry(core_BLAST_tab)
entry_thread.pack(pady=2)
#BlastDatabase
label_blst_db = tk.Label(core_BLAST_tab, text="BLAST Database Type:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_blst_db.pack(pady=2)
desc_blst_db = tk.Label(core_BLAST_tab, text="Specify the type of BLAST database (e.g., 'nucl' for nucleotide or 'prot' for protein).", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_blst_db.pack(pady=2)
entry_blst_db = tk.Entry(core_BLAST_tab)
entry_blst_db.pack(pady=2)
# strand
frame_strand = tk.Frame(core_BLAST_tab)
frame_strand.pack(pady=2)
label_strand = tk.Label(frame_strand, text="Strand:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_strand.pack(side=tk.LEFT, padx=5)

var_strand = tk.StringVar(value="plus")

radio_yes = tk.Radiobutton(frame_strand, text="plus", variable=var_strand, value="plus", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_strand, text="minus", variable=var_strand, value="minus", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
radio_no.pack(pady=2)

radio_both = tk.Radiobutton(frame_strand, text="both", variable=var_strand, value="both", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_both.pack(side=tk.LEFT, padx=5)
radio_both.pack(pady=2)
desc_strand = tk.Label(core_BLAST_tab, text="Choose the strand(s) of the orientation of Query ID for BLAST alignment:\n- plus: Align to the positive strand only.\n- minus: Align to the reverse complement only.\n- both: Align to both strands.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_strand.pack(pady=2)
#Dust
frame_dust = tk.Frame(core_BLAST_tab)
frame_dust.pack(pady=2)
label_dust = tk.Label(frame_dust, text="Dust:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_dust.pack(side=tk.LEFT, padx=5)

var_dust = tk.StringVar(value="Yes")

radio_yes = tk.Radiobutton(frame_dust, text="Yes", variable=var_dust, value="yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_dust, text="No", variable=var_dust, value="no", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
radio_no.pack(pady=2)

desc_dust = tk.Label(core_BLAST_tab, text="'Yes' enables dust filtering, masking low-complexity regions in sequences.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_dust.pack(pady=2)
#Addition
label_add_term_blst= tk.Label(core_BLAST_tab, text="Additional BLAST Parameters:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_add_term_blst.pack(pady=2)
entry_add_term_blst = tk.Entry(core_BLAST_tab)
entry_add_term_blst.pack(pady=2)
desc_add_term_blst = tk.Label(core_BLAST_tab, text="Specify additional command-line parameters for BLAST, if needed.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_add_term_blst.pack(pady=2)
#blst_btch
frame_blst_btch = tk.Frame(core_BLAST_tab)
frame_blst_btch.pack(pady=2)
label_blst_btch = tk.Label(frame_blst_btch, text="Executes BLAST Sequences Per Batches:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_blst_btch.pack(side=tk.LEFT, padx=5)

var_blst_btch = tk.StringVar(value="Yes")

radio_yes = tk.Radiobutton(frame_blst_btch, text="Yes", variable=var_blst_btch, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_blst_btch, text="No", variable=var_blst_btch, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
radio_no.pack(pady=2)
desc_blst_btch = tk.Label(core_BLAST_tab, text="'Yes' processes sequences in batches or uses all sequences against the main database.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_blst_btch.pack(pady=2)
#dlt_blst
frame_dlt_blst_btch = tk.Frame(core_BLAST_tab)
frame_dlt_blst_btch.pack(pady=2)
label_dlt_blst_btch = tk.Label(frame_dlt_blst_btch, text="Delete Batches After BLAST Stage:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_dlt_blst_btch.pack(side=tk.LEFT, padx=5)

var_dlt_blst_btch = tk.StringVar(value="Yes")

radio_yes = tk.Radiobutton(frame_dlt_blst_btch, text="Yes", variable=var_dlt_blst_btch, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_dlt_blst_btch, text="No", variable=var_dlt_blst_btch, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
radio_no.pack(pady=2)
desc_dlt_blst_btch = tk.Label(core_BLAST_tab, text="'Yes' deletes all BLAST batch files after processing.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_dlt_blst_btch.pack(pady=2)
#Clustering
Clustering_tab = add_tab(notebook, text="Clustering Stage")
#Filtering parameter
frame_filtrng = tk.Frame(Clustering_tab)
frame_filtrng.pack(pady=2)
label_filtrng = tk.Label(frame_filtrng, text="Filtering Parameter:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_filtrng.pack(side=tk.LEFT, padx=5)

var_filtrng = tk.StringVar(value="3")

radio_length = tk.Radiobutton(frame_filtrng, text="length", variable=var_filtrng, value="3", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_length.pack(side=tk.LEFT, padx=5)

radio_evalue = tk.Radiobutton(frame_filtrng, text="e-value", variable=var_filtrng, value="4", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_evalue.pack(side=tk.LEFT, padx=5)
radio_evalue.pack(pady=2)

radio_qcovs = tk.Radiobutton(frame_filtrng, text="qcovs", variable=var_filtrng, value="5", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_qcovs.pack(side=tk.LEFT, padx=5)
radio_qcovs.pack(pady=2)
radio_qcovhsp = tk.Radiobutton(frame_filtrng, text="qcovhsp", variable=var_filtrng, value="6", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_qcovhsp.pack(side=tk.LEFT, padx=5)
radio_qcovhsp.pack(pady=2)
desc_filtrng = tk.Label(Clustering_tab, text="BLAST parameters: Length\nE-value\nQuery coverage per subject sequence (qcovs)\nQuery coverage per high-scoring segment pair (qcovhsp).", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_filtrng.pack(pady=2)
#prmtr
label_mnm_prmtr= tk.Label(Clustering_tab, text="Minimum Parameter Value:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_mnm_prmtr.pack(pady=2)
entry_mnm_prmtr = tk.Entry(Clustering_tab)
entry_mnm_prmtr.pack(pady=2)
#Delimiting
frame_dlmting = tk.Frame(Clustering_tab)
frame_dlmting.pack(pady=2)
label_dlmting = tk.Label(frame_dlmting, text="Delimit All Values For Each Taxonomic Coverage:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_dlmting.pack(side=tk.LEFT, padx=5)

var_dlmting = tk.StringVar(value="Manual")

radio_Auto = tk.Radiobutton(frame_dlmting, text="Auto", variable=var_dlmting, value="Auto", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_Auto.pack(side=tk.LEFT, padx=5)

radio_Manual = tk.Radiobutton(frame_dlmting, text="Manual", variable=var_dlmting, value="Manual", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_Manual.pack(side=tk.LEFT, padx=5)
radio_Manual.pack(pady=2)
desc_dlmting = tk.Label(Clustering_tab, text="Choose 'Manual' for user-defined thresholds or 'Auto' to set percentages automatically from 0.99 (99%) to 0.01 (1%).", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_dlmting.pack(pady=2)
#Sequences
label_mnm_seq= tk.Label(Clustering_tab, text="Minimum Sequences Per Cluster:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_mnm_seq.pack(pady=2)
entry_mnm_seq = tk.Entry(Clustering_tab)
entry_mnm_seq.pack(pady=2)
#Class
label_mnm_Class= tk.Label(Clustering_tab, text="Minimum Classes Per Cluster:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_mnm_Class.pack(pady=2)
entry_mnm_Class = tk.Entry(Clustering_tab)
entry_mnm_Class.pack(pady=2)
#Order
label_mnm_order= tk.Label(Clustering_tab, text="Minimum Orders Per Cluster:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_mnm_order.pack(pady=2)
entry_mnm_order = tk.Entry(Clustering_tab)
entry_mnm_order.pack(pady=2)
#family
label_mnm_fmly= tk.Label(Clustering_tab, text="Minimum Families Per Cluster:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_mnm_fmly.pack(pady=2)
entry_mnm_fmly = tk.Entry(Clustering_tab)
entry_mnm_fmly.pack(pady=2)
#Gen
label_mnm_gen= tk.Label(Clustering_tab, text="Minimum Genus Per Cluster:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_mnm_gen.pack(pady=2)
entry_mnm_gen = tk.Entry(Clustering_tab)
entry_mnm_gen.pack(pady=2)
#Spp
label_mnm_spp= tk.Label(Clustering_tab, text="Minimum Species Per Cluster:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_mnm_spp.pack(pady=2)
entry_mnm_spp = tk.Entry(Clustering_tab)
entry_mnm_spp.pack(pady=2)
#thrds_clst
label_thrds_clstr= tk.Label(Clustering_tab, text="Threads Available For Clustering:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_thrds_clstr.pack(pady=2)
entry_thrds_clstr = tk.Entry(Clustering_tab)
entry_thrds_clstr.pack(pady=2)
desc_thrds_clstr = tk.Label(Clustering_tab, text="Specify the number of threads, processors, allocated for clustering analysis.\nTo prevent memory overlap or overuse, it is recommended to use two fewer threads than the total number of available processors.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_thrds_clstr.pack(pady=2)
#refinement
Top_Sequences_tab = add_tab(notebook, text="Filtering per Top Sequences")
#concat
frame_concat = tk.Frame(Top_Sequences_tab)
frame_concat.pack(pady=2)
label_concat = tk.Label(frame_concat, text="Concatenate Clusters From The Same Marker Prior to Filtering:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_concat.pack(side=tk.LEFT, padx=5)

var_concat = tk.StringVar(value="Yes")

radio_yes = tk.Radiobutton(frame_concat, text="Yes", variable=var_concat, value="Yes", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_yes.pack(side=tk.LEFT, padx=5)

radio_no = tk.Radiobutton(frame_concat, text="No", variable=var_concat, value="No", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_no.pack(side=tk.LEFT, padx=5)
radio_no.pack(pady=2)
desc_concat = tk.Label(Top_Sequences_tab, text="''Yes' combines clusters from the same marker before filtering.\n'No' filters each cluster separately.", font=("Arial", 12), bg="#1C1C1C", fg="white")
desc_concat.pack(pady=2)
#perlvl
frame_perlvl = tk.Frame(Top_Sequences_tab)
frame_perlvl.pack(pady=2)
label_perlvl = tk.Label(frame_perlvl, text="Taxonomic Level of Choice:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_perlvl.pack(side=tk.LEFT, padx=5)

var_perlvl = tk.StringVar(value="Species")

radio_class = tk.Radiobutton(frame_perlvl, text="Class", variable=var_perlvl, value="Class", 
                           font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_class.pack(side=tk.LEFT, padx=5)

radio_order = tk.Radiobutton(frame_perlvl, text="Order", variable=var_perlvl, value="Order", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_order.pack(side=tk.LEFT, padx=5)
radio_order.pack(pady=2)
radio_Family = tk.Radiobutton(frame_perlvl, text="Family", variable=var_perlvl, value="Family", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_Family.pack(side=tk.LEFT, padx=5)
radio_Family.pack(pady=2)
radio_Genus = tk.Radiobutton(frame_perlvl, text="Genus", variable=var_perlvl, value="Genus", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_Genus.pack(side=tk.LEFT, padx=5)
radio_Genus.pack(pady=2)
radio_Species = tk.Radiobutton(frame_perlvl, text="Species", variable=var_perlvl, value="Species", 
                          font=("Arial", 14, 'bold'), bg="#1C1C1C", fg="white")
radio_Species.pack(side=tk.LEFT, padx=5)
radio_Species.pack(pady=2)
#Numbrperlvl
label_top_sqs= tk.Label(Top_Sequences_tab, text="Top Sequences Per Taxonomic Level:",font=("Arial", 14,'bold'), bg="#1C1C1C", fg="white")
label_top_sqs.pack(pady=2)
entry_top_sqs = tk.Entry(Top_Sequences_tab)
entry_top_sqs.pack(pady=2)
def save_data():
    # Open the file dialog to choose a directory
    directory = filedialog.askdirectory(title="Select Directory")
    
    # If no directory is selected (the user cancels)
    if not directory:
        messagebox.showinfo("Cancelled", "No directory selected.")
        return
    
    # Define the full path to save the file
    file_path = os.path.join(directory, 'D4rwin_cfg.txt')
    
    # Check if the file already exists
    if os.path.exists(file_path):
        # Ask if the user wants to overwrite the file
        confirmation = messagebox.askyesno("File Exists", f"The file 'D4rwin_cfg.txt' already exists in this directory. Do you want to overwrite it?")
        if not confirmation:  # If user clicks "No"
            messagebox.showinfo("Cancelled", "The save operation was cancelled.")
            return  # Exit the function
    else:
        # Ask for confirmation before proceeding with the file operation
        confirmation = messagebox.askyesno("Confirm Save", "Are you sure you want to save the data?")
    
    if confirmation:  # If user clicks "Yes"
        try:
            # Retrieve data from the entry fields
            file_name = entry_file_name.get()
            txids = entry_txids.get()
            ncbi_tax_table = var_ncbi_tax_table.get()
            ncbi_type = entry_ncbi_type.get()
            targ1 = var_targeted.get()

            # Check for empty or non-empty values and append ";" when necessary
            targ2 = entry_targeted.get()
            if targ2:
                targ2 = targ2 + ";"
            else:
                targ2 = ""

            flex1 = var_flex.get()

            # Check for empty or non-empty values and append ";" when necessary
            flex2 = entry_flex.get()
            if flex2:
                flex2 = flex2 + ";"
            else:
                flex2 = ""

            excl1 = var_excl.get()

            # Check for empty or non-empty values and append ";" when necessary
            excl2 = entry_excl.get()
            if excl2:
                excl2 = excl2 + ";"
            else:
                excl2 = ""

            excl_txid1 = var_excl_txid.get()

            # Check for empty or non-empty values and append ";" when necessary
            excl_txid2 = entry_excl_txid.get()
            if excl_txid2:
                excl_txid2 = excl_txid2 + ";"
            else:
                excl_txid2 = ""

            excl_rec1 = var_excl_rec.get()

            # Check for empty or non-empty values and append ";" when necessary
            excl_rec2 = entry_excl_rec.get()
            if excl_rec2:
                excl_rec2 = excl_rec2 + ";"
            else:
                excl_rec2 = ""

            add_term = entry_add_term.get()
            max_len = entry_max_length.get()
            min_len = entry_min_length.get()
            batch_sz = entry_batch_sz.get()
            batch_dlt = var_batch_dlt.get()
            blastool = entry_blastool.get()
            evalue = entry_evalue.get()
            query = entry_query.get()
            thread = entry_thread.get()
            blst_db = entry_blst_db.get()
            strand = var_strand.get()
            dust = var_dust.get()
            add_term_blst = entry_add_term_blst.get()
            blst_btch = var_blst_btch.get()
            dlt_blst_btch = var_dlt_blst_btch.get()
            filtrng = var_filtrng.get()
            mnm_prmtr = entry_mnm_prmtr.get()
            dlmting = var_dlmting.get()
            mnm_seq = entry_mnm_seq.get()
            mnm_Class = entry_mnm_Class.get()
            mnm_order = entry_mnm_order.get()
            mnm_fmly = entry_mnm_fmly.get()
            mnm_gen = entry_mnm_gen.get()
            mnm_spp = entry_mnm_spp.get()
            thrds_clstr = entry_thrds_clstr.get()
            concat = var_concat.get()
            perlvl = var_perlvl.get()
            top_sqs = entry_top_sqs.get()

            # Proceed with the file operation
            with open(file_path, 'w') as f:
                f.write(f"################### Core information ###################\n")
                f.write(f"File Name={file_name};\n")
                f.write(f"Taxonomic Identification of Interest (Txids)={txids};\n")
                f.write(f"Use NCBI Taxonomic Table={ncbi_tax_table};\n")
                f.write(f"\n")
                f.write(f"################### Assembling Taxonomic Database Phase ###################;\n")
                f.write(f"NCBI Database Type={ncbi_type};\n")
                f.write(f"Targeted Search={targ1};{targ2}\n")
                f.write(f"Flexible Search={flex1};{flex2}\n")
                f.write(f"Exclude Terms={excl1};{excl2}\n")
                f.write(f"Exclude Txids={excl_txid1};{excl_txid2}\n")
                f.write(f"Exclude Records={excl_rec1};{excl_rec2}\n")
                f.write(f"Additional NCBI Search Terms={add_term};\n")
                f.write(f"Length=AND {min_len}[SLEN]:{max_len}[SLEN];\n")
                f.write(f"Batch Size={batch_sz};\n")
                f.write(f"Delete NCBI Batches After Assembling Database Phase={batch_dlt};\n")
                f.write(f"\n")
                f.write(f"################### BLAST Stage ###################\n")
                f.write(f"BLAST Tool={blastool};\n")
                f.write(f"E-value={evalue};\n")
                f.write(f"Query Coverage={query};\n")
                f.write(f"Threads={thread};\n")
                f.write(f"BLAST Database Type={blst_db};\n")
                f.write(f"Strand={strand};\n")
                f.write(f"Dust={dust};\n")
                f.write(f"Additional BLAST Parameters={add_term_blst};\n")
                f.write(f"Executes BLAST Sequences Per Batches={blst_btch};\n")
                f.write(f"Delete Batches After BLAST Stage={dlt_blst_btch};\n")
                f.write(f"\n")
                f.write(f"################### Clustering Stage ###################\n")
                f.write(f"Filtering Parameter={filtrng};\n")
                f.write(f"Minimum Parameter Value={mnm_prmtr};\n")
                f.write(f"Delimit All Values For Each Taxonomic Coverage={dlmting};\n")
                f.write(f"Minimum Sequences Per Cluster={mnm_seq};\n")
                f.write(f"Minimum Classes Per Cluster={mnm_Class};\n")
                f.write(f"Minimum Orders Per Cluster={mnm_order};\n")
                f.write(f"Minimum Families Per Cluster={mnm_fmly};\n")
                f.write(f"Minimum Genus Per Cluster={mnm_gen};\n")
                f.write(f"Minimum Species Per Cluster={mnm_spp};\n")
                f.write(f"Threads Available For Clustering={thrds_clstr};\n")
                f.write(f"\n")
                f.write(f"################### Filtering per Top Sequences Option ###################\n")
                f.write(f"Concatenate Clusters From The Same Marker Prior to Filtering={concat};\n")
                f.write(f"Taxonomic Level of Choice={perlvl};\n")
                f.write(f"Top Sequences Per Taxonomic Level={top_sqs};\n")

            # Show a success message box once data is saved
            messagebox.showinfo("Success", "Configuration file saved successfully!")

        except Exception as e:
            # If there's an error saving, show an error message
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

# Assuming you have an existing Tkinter root window, add a button to trigger the save function

# Create a save button to store the entered data
save_button = tk.Button(taxonomic_info_tab, 
                        text="Save Data", 
                        command=save_data, 
                        font=("Arial", 14, 'bold'), 
                        bg="#ff5733",  # Change this to the desired background color
                        fg="black")  # You may want to change the text color as well to contrast with the background
save_button.pack(pady=10)
save_button = tk.Button(core_info_tab, 
                        text="Save Data", 
                        command=save_data, 
                        font=("Arial", 14, 'bold'), 
                        bg="#ff5733",  # Change this to the desired background color
                        fg="black")  # You may want to change the text color as well to contrast with the background
save_button.pack(pady=10)
save_button = tk.Button(core_BLAST_tab, 
                        text="Save Data", 
                        command=save_data, 
                        font=("Arial", 14, 'bold'), 
                        bg="#ff5733",  # Change this to the desired background color
                        fg="black")  # You may want to change the text color as well to contrast with the background
save_button.pack(pady=10)
save_button = tk.Button(Clustering_tab, 
                        text="Save Data", 
                        command=save_data, 
                        font=("Arial", 14, 'bold'), 
                        bg="#ff5733",  # Change this to the desired background color
                        fg="black")  # You may want to change the text color as well to contrast with the background
save_button.pack(pady=10)
save_button = tk.Button(Top_Sequences_tab, 
                        text="Save Data", 
                        command=save_data, 
                        font=("Arial", 14, 'bold'), 
                        bg="#ff5733",  # Change this to the desired background color
                        fg="black")  # You may want to change the text color as well to contrast with the background
save_button.pack(pady=10)
# Pack the notebook
notebook.pack(expand=1, fill="both")
   # Save data to output.txt
# Run the Tkinter event loop
root.mainloop()
